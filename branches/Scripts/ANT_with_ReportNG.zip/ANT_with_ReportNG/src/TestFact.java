import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;

public class TestFact {
	
	private Selenium selenium;
	
	@BeforeClass
	public void startSelenium(){
		selenium = new DefaultSelenium("localhost",4444,"*chrome","http://google.com");
		selenium.start();
	}
	
	@AfterClass
	public void stopSelenium(){
		selenium.stop();
	}
	@DataProvider(name="data") 
	public Object[][] data(){
		return new Object[][]{
				{"1!"},
				{"2!"}
		};
	}
	@Test(dataProvider="data")
	public void check(String input){
		selenium.open("/");
		selenium.type("q", input+"=");
		selenium.click("btnG");
	}
	
}
