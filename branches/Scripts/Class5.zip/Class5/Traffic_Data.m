
Timer_Count_limit = 55;