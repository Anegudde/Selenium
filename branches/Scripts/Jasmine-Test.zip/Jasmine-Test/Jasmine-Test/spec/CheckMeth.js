 describe("Creation of Objects and Methods", function() {
	 var funcObject;
	 beforeEach(function() {
	 funcObject = new FuncObj();
	 });
	 it("Call Old Method", function() {
	 expect(funcObject.oldmethod()).toContain("Old");
	 });	
	 it("Call New Method", function() {
	 expect(funcObject.newmethod()).toContain("New");
	 });	
});
