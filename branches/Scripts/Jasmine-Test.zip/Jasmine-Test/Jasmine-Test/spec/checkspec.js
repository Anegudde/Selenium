jasmine.DEFAULT_TIMEOUT_INTERVAL = jasmine.getEnv().defaultTimeoutInterval = 20000;
describe( "Sample Javascript Function Tests", function () {
  it("Hello World?", function () {
	  expect(helloWorld()).toEqual("Hello World");
  });

  it("Exit World?", function () {
	  expect(ExitWorld()).toContain("World");
  });
});

describe("Addition operator", function () {
    it("adds two numbers together : should be equal to 7", function () {
        expect(1 + 2).toEqual(3);
    });
});
/*
describe ( "Switch Case#1", function () {
  it("Switch Case Logic?", function () {
	  expect(switchValues(1)).toContain("History");
  }); 
});
*/
// expect() syntax 
describe ("Check operator", function (){
	var spot = {species : "Labrador"};
	var spot1 = {species : "Labrador"};
	it("Check ToBe operator", function() {
	expect(spot).toBe(spot);
	});	
	it("Check ToBe operator", function() {
	expect(spot).not.toBe(spot1);
	});
	
	var arr =[1,2,3];
	it("Check ToEqual operator", function() {
	expect(arr).not.toEqual([1,2]);	
	});
	it("Check ToBe operator", function() {
	expect(arr).not.toBe(1,2);	
	});
	it("Check toBeTruthy operator", function() {
	expect(true).toBeTruthy();
	});
	it("Check toBeTruthy operator", function() {
	expect(12).toBeTruthy();
	});
	it("Check toBeTruthy operator", function() {
	expect({}).toBeTruthy();
	});	
	it("Check toBeFalsy operator", function() {
	expect(false).toBeFalsy();
	});
	it("Check toBeFalsy operator", function() {
	expect(null).toBeFalsy();
	});
	it("Check toBeFalsy operator", function() {
	expect("").toBeFalsy();
	});	
	it("Check toContain operator", function() {
	expect([1, 2, 3, 4]).toContain(3);
	});	
	it("Check toContain operator", function() {
	expect(["Penguin", "Turtle", "Pig", "Duck"]).toContain("Duck");
	});		
	var dog = { name: "Fido" };
	it("Check toContain operator", function() {
	expect([
	 { name: "Spike" },
	 { name: "Fido" },
	 { name: "Spot" }
		]).toContain(dog);
	});	
	it("Check toMatch operator", function() {
	expect("foo bar").toMatch(/bar/);
	});
	it("Check toMatch operator", function() {
	expect("horse_ebooks.jpg").toMatch(/\w+.(jpg|gif|png|svg)/i);
	});
	it("Check toMatch operator", function() {
	expect("jasmine@example.com").toMatch("\[a-z]+@\[a-z]+\.com");
	});
	var throwMeAnError = function() {throw new Error();
	};
	it("Check Throw operator", function() {
	expect(throwMeAnError).toThrow();
	});
	it("Check Throw for Function CALCULATE operator", function() {
	expect(function() {	calculate("BAD INPUT");	}).toThrow();
	})
	
	it("Checking for CUSTOM handlers for toBeLarge", function() {
	expect(5).not.toBeLarge(); // failure
	})	
	it("Checking for CUSTOM handlers for toBeLarge", function() {
	expect(200).toBeLarge(); // success
	})
	it("Checking for CUSTOM handlers for toBeLarge", function() {
	expect(12).not.toBeLarge(); // success
	})

	it("Checking for CUSTOM handlers for toBeWithinOf", function() {
	// Expect 6 to be within 2 of 5 (between 3 and 7, inclusive).
	expect(6).toBeWithinOf(2, 5);
	})	
 
 
	
});

/*  List of Functions 
expect(a.foo).toBeDefined();
expect(a.bar).not.toBeDefined();
expect(null).toBeNull();
expect(foo).toBeNull();
expect(foo).not.toBeNull();
expect(foo).toBeTruthy();
expect(a).toBeFalsy();
expect(a).toContain("bar");
expect(a).not.toContain("quux");
expect(e).toBeLessThan(pi);
expect(pi).not.toBeLessThan(e);
expect(pi).toBeGreaterThan(e);
expect(foo).toEqual(1);
*/