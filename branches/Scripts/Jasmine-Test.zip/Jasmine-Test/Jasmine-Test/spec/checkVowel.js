describe("Disemvoweler", function() {
	it("should remove all lowercase vowels", function() {
	expect(disemvowel1("Hello world")).toEqual("Hll wrld");
	});
	it("should remove all uppercase vowels", function() {
	expect(disemvowel2("Artistic Eagle")).toEqual("rtstc gl");
	});
	it("shouldn't change empty strings", function() {
	expect(disemvowel1("")).toEqual("");
	});
	it("shouldn't change strings with no vowels", function() {
	expect(disemvowel1("Mhmm")).toEqual("Mhmm");
	});
});