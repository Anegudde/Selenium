function FuncObj(){
  this.oldmethod = function(){return "Old"};
  this.newmethod = function(){return "New"};
}