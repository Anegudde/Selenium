 function disemvowel1(str) {
	return str.replace(/a|e|i|o|u/g, "");
 }
 
 function disemvowel2(str) {
	return str.replace(/a|e|i|o|u/gi, "");
 }
