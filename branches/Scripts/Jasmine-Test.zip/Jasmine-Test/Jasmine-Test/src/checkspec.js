/* Java Script Function
 @Name: 
 @param: None
 @param: string
*/
function helloWorld(){
	return "Hello World";
}

/* Java Script Function
 @Name: 
 @param: None
 @param: string
*/
function ExitWorld(){
	return "World is not Enough";
}

beforeEach(function() {
	 this.addMatchers({ toBeLarge: function() {
			this.message = function() {
			return "Expected " + this.actual + " to be large";
			};
		return this.actual > 100;}
	 });
});

beforeEach(function() {
	 this.addMatchers({
	 toBeWithinOf: function(distance, base) {
		 this.message = function() {
			 var lower = base - distance;
			 var upper = base + distance;
			 return "Expected " + this.actual + " to be between " +
			 lower + " and " + upper + " (inclusive)";
			 };
		return Math.abs(this.actual - base) <= distance;}
	 });
 });

/* Java Script Function 
 @Name: 
 @param: None
 @param: None
function switchValues(var val) {
if( val == 1 ){
   return "History";
}else if( val == 2 ){
   return "Maths";
}else if( val == 3 ){
   return "Economics"
}else{
  return "Boring";
}
*/

