function Calculator(a,b){
  this.a=a;
  this.b=b;  
  this.add=function(){return (this.a + this.b)};
  this.sub=function(){return (this.a - this.b)};
  this.mul=function(){return (this.a * this.b)};
  this.div=function(){return (if(this.b !=0)
	return (this.a/this.b)
	else return "Invalid";
  )};
};
/*
 function calc.add(a, b) {
	return calc.replace(a+b);
 }
 
 function calc.sub(a, b) {
	return calc.replace(a-b);
 }
 
 function calc.mul(a, b) {
	return calc.replace(a*b);
 }
 
 function calc.div(a, b) {
	if (b!=0)
	return calc.replace(a / b);
	else
	return "Not Valid";
 }
*/