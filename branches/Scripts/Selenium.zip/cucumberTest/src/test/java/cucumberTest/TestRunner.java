package cucumberTest;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestRunner {

	@Test
	public void test() {
		//fail("Not yet implemented");
		
	}
	
	@RunWith(Cucumber.class)
	@Cucumber.Options(format={"pretty","html:reports/test-report"},tags= "@smokeTest")
	public class CucumberRunner {
	}
}
