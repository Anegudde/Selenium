package cucumberTest;

import org.junit.Test;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

public class TestRunner {

	@Test
	public void test() {
		//fail("Not yet implemented");
		
	}
	
	@RunWith(Cucumber.class)
	@CucumberOptions
			(
			    plugin={"pretty", "html:target/cucumber-html-report"},
			    tags= "@smokeTest"
			)
	public class CucumberRunner {
		
		
	}
}
