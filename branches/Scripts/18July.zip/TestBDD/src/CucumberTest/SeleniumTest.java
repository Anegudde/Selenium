package CucumberTest;


public class SeleniumTest{
	
	public static void main(String [] args){
		
		
	}
	
}