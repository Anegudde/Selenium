/*************************************************************************
WARNING
   Copyright 2010 Hamilton Sundstrand Corporation. This document is the
   property of Hamilton Sundstrand Corporation ("HSC"). You may not possess,
   use, copy or disclose this document or any information in it, for any
   purpose, including without limitation, to design, manufacture or repair
   parts, or obtain any government approval to do so, without HSC's express
   written permission. Neither receipt nor possession of this document
   alone, from any source, constitutes such permission. Possession, use,
   copying or disclosure by anyone without HSC's express written permission
   is not authorized and may result in criminal and/or civil liability.
  ***************************************************************************

                              *************************
                              *                       *
                              *       Tables.c        *
                              *                       *
                              *************************

unit title:  Tables.c
author(s):  Anuradha
****************************************************************************
description:

     This module contains the the array population with the addresses of the
     functions

   FUNCTIONS
    None.

partitioning information VESA server
****************************************************************************
VERSION        : %full_filespec:  %
****************************************************************************/
/* included modules:  */

/**************************************************************************/

#include "Tables.h"
#include "GW_APP_ssx_healthmonitor_Per_Func.h"

TESTSTATUS (*FunctionPtr[])(void) = {
               Ver_NO_Test,
               GW_APP_ssx_healthmonitor_Per_Func,
               
};


