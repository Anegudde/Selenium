/* included modules:  */
#include "BT/BT_APIs.h"
#include "SS/SS_Tables.h"
#include "SS/SS_APIs.h"
#include "src/SS_FaultCodes.h"
#include "SS/SS_ECC_Test.h"
#include "SS/SS_WD_Test.h"
#include "ssx_healthmonitor.h"
#include "Application_Fault_Codes.h"
#include "gateway_bpcu_nvm.h"
#include "MPC5554/CSA_Macros.h"
#include "Fault_Recorder.h"
#include "cold_reset.h"
#include "EventCode.h"
#include "Make_Snapshot_Data.h"
#include "Activate_Shutdown.h"


int testflag ;
int testflag1 ;
int testflag2 ;
int Activate_Shutdown_test;
int SS_ECC_Test_flag;
int SS_WD_Test_flag;
int POST_RAM_PARITY_TEST_Flag;
int POST_WDT_EARLYSTROBE_TEST_Flag;
int POST_WDT_LATESTROBE_TEST_Flag;
int gcu_discrete_output_ports_deactivate_test;
SS_U32 waitCount_global;
int app_WD_Reset_Flag;

int SS_TIMER_ReadDelayTimer_counter;
int POST_RAM_PARITY_TEST_counter;
int POST_WDT_EARLYSTROBE_TEST_counter;

int Flag;
int POST_FLASH_TEST_flag;
int POST_COLDRESET_flag;
SS_U32 VerifiedStoreEventCode_Test_flag;
int EventCode_Val ;
int RunningCheck_flag;
int POST_ECC_TEST_counter;
int BT_WD_Reset_flag;

BT_BOOL BT_WD_IsColdStart( void)
{
	switch(testflag)
	{
		case 0:
		case 1:
		{
			if(POST_FLASH_TEST_flag == 1)
			{
				++testflag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_FAILED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_TRUE;
			}
			else if(POST_FLASH_TEST_flag == 3)
			{
				++testflag;
				PowerUpData.TotalTestRuns = 0;
				PowerUpData.TestStatus = POST_FAILED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_TRUE;
			}
			else if(POST_FLASH_TEST_flag == 5)
			{
				++testflag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_TRUE;
			}
			else if(POST_FLASH_TEST_flag == 15)
			{
				++testflag;
				if(PowerUpData.CurrentTest == POST_FLASH_TEST)
				{
					PowerUpData.CurrentSubtest = 0xFF;
				}
				else
				{
					PowerUpData.CurrentSubtest = 2;
				}
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_TRUE;
			}
			else
			{
				++POST_FLASH_TEST_flag;
				++testflag;
				PowerUpData.InPOST = SS_TRUE;
				return SS_TRUE;
			}
			break;
		}

		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		{												/* condition to reach the else if(PowerUpData.InPOST == SS_TRUE) */
			if(testflag2 == 0 || testflag2 ==3 )
			{
				++testflag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_FAILED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_FALSE;
			}
			else if(testflag2 == 1)
			{
				++testflag;
				if(Flag == 1)
				{
					PowerUpData.TotalTestRuns = 0xFF;
				}
				else
				{
					PowerUpData.TotalTestRuns = 0;
				}
				PowerUpData.TestStatus = POST_FAILED ;
				PowerUpData.InPOST = SS_TRUE;
				return SS_FALSE;
			}
			else if(testflag2 == 4)
			{	++testflag;
				++POST_RAM_PARITY_TEST_Flag;
				++POST_WDT_EARLYSTROBE_TEST_Flag;
				++POST_WDT_LATESTROBE_TEST_Flag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				PowerUpData.CurrentSubtest = 0;
				PowerUpData.CurrentTest = POST_RAM_PARITY_TEST;
				return SS_FALSE;
			}
			else if(testflag2 == 6)
			{	++testflag;
				++POST_RAM_PARITY_TEST_Flag;
				++POST_WDT_EARLYSTROBE_TEST_Flag;
				++POST_WDT_LATESTROBE_TEST_Flag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				PowerUpData.CurrentSubtest = 0xFF;
				return SS_FALSE;
			}
			else if(testflag2 == 7)
			{	++testflag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				PowerUpData.CurrentSubtest = 0xFF;
				PowerUpData.CurrentTest =   POST_WDT_EARLYSTROBE_TEST;
				return SS_FALSE;
			}
			else if(testflag2 == 8)
			{	++testflag;
				PowerUpData.TotalTestRuns = 2;
				PowerUpData.TestStatus = POST_PASSED ;
				PowerUpData.InPOST = SS_TRUE;
				PowerUpData.CurrentSubtest = 0xFF;
				PowerUpData.CurrentTest =   POST_WDT_LATESTROBE_TEST;
				return SS_FALSE;
			}

			else
			{
					if(POST_RAM_PARITY_TEST_Flag == 3)
					{
						++testflag;

						PowerUpData.TotalTestRuns = 2;
						PowerUpData.TestStatus = POST_FAILED ;
						PowerUpData.InPOST = SS_TRUE;
						return SS_FALSE;
					}
					else if(POST_RAM_PARITY_TEST_Flag == 5)
					{
						++testflag;
						PowerUpData.TotalTestRuns = 0;
						PowerUpData.TestStatus = POST_FAILED ;
						PowerUpData.InPOST = SS_TRUE;
						return SS_FALSE;
					}
					else
					{

						if(POST_WDT_EARLYSTROBE_TEST_Flag == 12)
						{
							++testflag;

							PowerUpData.TotalTestRuns = 2;
							PowerUpData.TestStatus = POST_FAILED ;
							PowerUpData.InPOST = SS_TRUE;
							return SS_FALSE;
						}
						else if(POST_WDT_EARLYSTROBE_TEST_Flag == 16)
						{
							++testflag;
							PowerUpData.TotalTestRuns = 0;
							PowerUpData.TestStatus = POST_FAILED ;
							PowerUpData.InPOST = SS_TRUE;
							return SS_FALSE;
						}
						else
						{
							if(POST_WDT_LATESTROBE_TEST_Flag == 28)
							{
								++testflag;

								PowerUpData.TotalTestRuns = 2;
								PowerUpData.TestStatus = POST_FAILED ;
								PowerUpData.InPOST = SS_TRUE;
								return SS_FALSE;
							}
							else if(POST_WDT_LATESTROBE_TEST_Flag == 33)
							{
								++testflag;
								PowerUpData.TotalTestRuns = 0;
								PowerUpData.TestStatus = POST_FAILED ;
								PowerUpData.InPOST = SS_TRUE;
								return SS_FALSE;
							}
							else
							{

								if(POST_COLDRESET_flag == 59)
								{
									++testflag;

									PowerUpData.TotalTestRuns = 0;
									PowerUpData.InPOST = SS_TRUE;
									return SS_FALSE;
								}
								else if(POST_COLDRESET_flag == 69)
								{
									++testflag;
									PowerUpData.TotalTestRuns = 0xFF;
									PowerUpData.InPOST = SS_TRUE;
									return SS_FALSE;
								}
								else if(POST_COLDRESET_flag == 79)
								{
									++testflag;
									PowerUpData.TotalTestRuns = 1;
									if(PowerUpData.CurrentTest == POST_COLDRESET)
									{
										PowerUpData.CurrentSubtest = 0xFF;
									}
									else
									{
										PowerUpData.CurrentSubtest = 3;
									}
									PowerUpData.InPOST = SS_TRUE;
									return SS_FALSE;
								}
								else
								{
									if( PowerUpData.CurrentTest == POST_WDT_EARLYSTROBE_TEST)
									{
										++POST_RAM_PARITY_TEST_counter;
									}
									else if(PowerUpData.CurrentTest == POST_WDT_LATESTROBE_TEST)
									{
										++POST_WDT_EARLYSTROBE_TEST_counter;
									}
									else if(PowerUpData.CurrentTest == POST_RAM_PARITY_TEST)
									{
										++POST_ECC_TEST_counter;
									}
									++testflag;
									++POST_RAM_PARITY_TEST_Flag;
									++POST_WDT_EARLYSTROBE_TEST_Flag;
									++POST_WDT_LATESTROBE_TEST_Flag;
									++POST_COLDRESET_flag;
									PowerUpData.TotalTestRuns = 2;
									PowerUpData.TestStatus = POST_PASSED ;
									PowerUpData.InPOST = SS_TRUE;
									PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;

									return SS_FALSE;
								}
							}
						}
					}
			}
			break;
		}
		case 25:
			{
				PowerUpData.CurrentTest = POST_COLDRESET;
				PowerUpData.InPOST = SS_FALSE;
				return SS_TRUE;
				break;
			}

		default:
		{
			PowerUpData.CurrentTest = POST_COLDRESET;
			PowerUpData.InPOST = SS_FALSE;

			return SS_FALSE;
			break;
		}
	}

}

void Activate_Shutdown( SS_U32 faultHandlerExitType,
                        SS_U32 faultCode,
                        SS_FAULT_SNAPSHOT_DATA *faultSnapshotData)
{
	Activate_Shutdown_test = 1;
	return;
}

void GCU_IO_HW_Safe_Mode (void)
{
	return;
}

void gcu_discrete_output_ports_deactivate (void)
{
	gcu_discrete_output_ports_deactivate_test = 1;
	return;
}


void app_WD_Reset( void )
{
	app_WD_Reset_Flag = 1;
	return;
}

SS_FAULT_SNAPSHOT_DATA *Make_Snapshot_Data(SS_U32 snapshot1,
                                           SS_U32 snapshot2,
                                           SS_U32 snapshot3,
                                           SS_U32 snapshot4)
{
	return;
}

void SS_WD_Test (SS_U32 waitCount )
{
	waitCount_global = waitCount;
	SS_WD_Test_flag = 1;
	return;
}


SS_ECC_TEST_STATUS SS_ECC_Test (void)
{
	if(SS_ECC_Test_flag == 0)
	{
		return SS_ECC_TEST_FAILED;
	}
	else
	{
		return SS_ECC_TEST_PASSED;
	}
}

void BT_WD_Trigger(void)
{
	return;
}
void SS_TIMER_StartDelayTimer(SS_TIMER   *DelayTimer, SS_U64   Delay1)
{
	if(PowerUpData.CurrentSubtest == LVPS_PSMON_POS5V_HI)
	{
		testflag1 = 1;
		return;
	}

	else if(PowerUpData.CurrentSubtest == LVPS_PSMON_POS5V_LO)
	{
		testflag1 = 2;
		return;
	}

	else if(PowerUpData.CurrentSubtest == LVPS_PSMON_POS3R3V_HI)
	{
		testflag1 = 3;
		return;
	}
	else
	{
		testflag1 = 4;
		return;
	}
}

SS_TIMER_STATUS SS_TIMER_ReadDelayTimer(SS_TIMER   *DelayTimer)
{
	if(SS_TIMER_ReadDelayTimer_counter == 0)
	{
		++SS_TIMER_ReadDelayTimer_counter;
		return SS_TIMER_NOT_TIMED_OUT ;
	}
	else
	{
		return  SS_TIMER_TIMED_OUT;
	}

}

BT_U32 BT_UT_Calculate_CRC(void* Starting_Address,BT_U32 Size,BT_U32 Seed)
{
	if(RunningCheck_flag == 1)
	{
		Flag = 10;
		return  0x1FFFF7;
	}
	else
	{
		Flag = 20;
		PowerUpData.CurrentSubtest = 0xFF;
		return  *(SS_U32 *)APP_CRC_ADDR;
	}
}

void BT_WD_Reset(void)
{
	BT_WD_Reset_flag = 1;
	return;
}
void VerifiedStoreEventCode(SS_U32 post_EC)
{
	VerifiedStoreEventCode_Test_flag = post_EC;
	return;
}

void COLD_Reset( void )
{
	return;
}

SS_U32 EventCode(void)
{
	if(EventCode_Val == 1)
	{
		return EC_POST_COLDRESET_COMPLETE;
	}
	else
	{
		return EC_POST_COLDRESET_IN_PROCESS;
	}
}

void SS_INTR_Enable (SS_U32  EnableMSR )
{
}
