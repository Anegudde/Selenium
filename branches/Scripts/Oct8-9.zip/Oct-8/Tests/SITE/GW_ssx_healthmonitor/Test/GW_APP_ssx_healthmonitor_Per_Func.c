/****************************************************************************
**
**                                 WARNING
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
****************************************************************************
**
** Test Identification: GW_APP_ssx_healthmonitor_Per_Func.c
**
** This file's version information::
** $RCSfile: GW_APP_ssx_healthmonitor_Per_Func.c $
** $Revision: 1.5 $
**
** Software Configuration Index (SCI): DS10596/224 
**
** Software Level: A
**
*****************************************************************************
**
** Author(s): Anuradha 
**
******************************************************************************
**
**                    History
**
**  Date        Initials    Description
**
** 27/11/12      AD       Initial version  
** 07/12/12      AD       Updated for Review comments
** 09/23/13      RDK      Updated for failsafe SCA changes - CR 5115   
**
******************************************************************************
**
** Test Support Environment: DS10596/225
**
*****************************************************************************
**
** Requirements Tested: SWRD : 	BPCU_SWRD-40338
**                      		BPCU_SWRD-40339
**                      		BPCU_SWRD-40336
**                      		BPCU_SWRD-40337
**                      		BPCU_SWRD-40341
**                      		BPCU_SWRD-40342
**                      		BPCU_SWRD-40340
**                      		BPCU_SWRD-40343
**                      		BPCU_SWRD-40345
**                      
**                      SWDD : 	787_GW_BPCU_SWDD-20174
**                      		787_GW_BPCU_SWDD-20173
**                      		787_GW_BPCU_SWDD-20867
**                      		787_GW_BPCU_SWDD-20869
**                      		787_GW_BPCU_SWDD-20868
**                      		787_GW_BPCU_SWDD-20172
**                      		787_GW_BPCU_SWDD-20171
**                      		787_GW_BPCU_SWDD-20177
**                      		787_GW_BPCU_SWDD-20178
**                      		787_GW_BPCU_SWDD-20179
**                         		787_GW_BPCU_SWDD-20870
**                         		787_GW_BPCU_SWDD-20176
**                         		787_GW_BPCU_SWDD-20198
**                         		787_GW_BPCU_SWDD-20601   
**                         		787_GW_BPCU_SWDD-20602  
**                         		787_GW_BPCU_SWDD-20180 
**                         		
**
**
*****************************************************************************
**
** Units Tested: ssx_healthmonitor.c
**
******************************************************************************
**
** Assumptions and Constraints :
** 
** None
*****************************************************************************
**
** Criteria for Evaluating Results:
**   All data listed under Expected Outputs must exactly match the listed
**   result or range expressed.
**
*****************************************************************************/

#include "GW_APP_ssx_healthmonitor_Per_Func.h"

/* included modules:  */
#include "BT/BT_APIs.h"
#include "SS/SS_Tables.h"
#include "SS/SS_APIs.h"
#include "src/SS_FaultCodes.h"
#include "SS/SS_ECC_Test.h"
#include "SS/SS_WD_Test.h"
#include "ssx_healthmonitor.h"
#include "Application_Fault_Codes.h"
#include "gateway_bpcu_nvm.h"
#include "MPC5554/CSA_Macros.h"
#include "Fault_Recorder.h"
#include "cold_reset.h"
#include "EventCode.h"               
#include "Make_Snapshot_Data.h"
#include "Activate_Shutdown.h"
#include "appl_watchdog_trigger.h"


extern int testflag;
extern int testflag1;
extern int testflag2 ;
extern int Activate_Shutdown_test;
extern int SS_ECC_Test_flag;
extern int SS_WD_Test_flag;
extern int gcu_discrete_output_ports_deactivate_test;

extern int POST_RAM_PARITY_TEST_Flag;
extern int POST_WDT_EARLYSTROBE_TEST_Flag;
extern int POST_WDT_LATESTROBE_TEST_Flag;
extern SS_U32 waitCount_global;
extern int app_WD_Reset_Flag;
extern int SS_TIMER_ReadDelayTimer_counter;
extern int POST_RAM_PARITY_TEST_counter;
extern int POST_WDT_EARLYSTROBE_TEST_counter;

extern int Flag;
extern int POST_FLASH_TEST_flag;
extern int POST_COLDRESET_flag;
extern SS_U32 VerifiedStoreEventCode_Test_flag;
extern int EventCode_Val ;
extern int POST_ECC_TEST_counter;
extern int RunningCheck_flag;
extern int BT_WD_Reset_flag;

SS_BOOL Watchdog_Started;

TESTSTATUS GW_APP_ssx_healthmonitor_Per_Func(void)
{

    /* For switching into the different test cases */
    static short TestCase;

   /* To hold the Test status */
   TESTSTATUS Status = IN_PROGRESS;

   /*To hold and print the test case results */
   VER_BOOLEAN TestCaseResult;

   /* Variable to hold the number of test failures */
   static unsigned int Failcount = 0;

    switch (TestCase)
    {

        case 0:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 1                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                            ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173                     ");
    Print_Test_Header("**                                  787_GW_BPCU_SWDD-20869                     ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.) To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor will perform a low voltage power     ");
	Print_Test_Header("**          supply monitor test to verify correct operation of the low  	      ");
	Print_Test_Header("**          voltage power upply monitors.                                      ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_5V_HI_I stim,    ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS5V_HI_FAIL fault code      ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
			PowerUpData.TestStatus = POST_FAILED;
			
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
			(*( volatile unsigned char *)((0xC3F90600+(120)))) = 1;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 0;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS5V_HI;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 1 && (*( volatile unsigned char *)((0xC3F90600+(120)))) == 0)
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, testflag1, TestCaseResult);
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
				Print_Test_Case_Values (0, TRUE, 16, (*( volatile unsigned char *)((0xC3F90600+(120)))), TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 0 */
	
				
		case 1:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 2                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                        	  ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                        	  ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173   				  ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20174   				  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)  To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor will perform a low voltage power     ");
	Print_Test_Header("**          supply monitor test to verify correct  operation of the low        ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_3R3V_HI_I stim,  ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS3R3V_HI_FAIL fault code    ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
			PowerUpData.TestStatus = POST_FAILED;
			
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
			(*( volatile unsigned char *)((0xC3F90600+(118)))) == 1; 
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 0;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_HI;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 3 												/* verifying writing POST_LVPS_PSMON_POS3R3V_HI_FAIL code in to NVM*/
			&& Activate_Shutdown_test == 1 									/* by invoking Activate_Shutdown() function */							
			&& (*( volatile unsigned char *)((0xC3F90600+(118)))) == 0)					
            {																						
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (3, TRUE, 16, testflag1, TestCaseResult);
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
			Print_Test_Case_Values (0, TRUE, 16, (*( volatile unsigned char *)((0xC3F90600+(118)))), TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 1 */
	
		
		
		case 2:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 3                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                        	  ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                        	  ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173   				  ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20867   				  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)  To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**         Communications Microprocessor  will perform a low voltage power supply");
	Print_Test_Header("**          monitor test to verify correct  operation of the low  voltage power");
	Print_Test_Header("**          supply monitors.                                                   ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_3R3V_LO_I stim,  ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS3R3V_LO_FAIL fault code    ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**        									                                   ");
    Print_Test_Header("******************************************************************************/");
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
			PowerUpData.TestStatus = POST_FAILED;
			
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
			(*( volatile unsigned char *)((0xC3F90600+(117)))) == 1; 
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 0;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 4 && (*( volatile unsigned char *)((0xC3F90600+(117)))) == 0) /* verifying writing LVPS_PSMON_POS3R3V_LO code in to NVM*/
            {                                                                              /* by invoking Activate_Shutdown() function */							
                TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (4, TRUE, 16, testflag1, TestCaseResult);
			Print_Test_Case_Values (0, TRUE, 16, (*( volatile unsigned char *)((0xC3F90600+(117)))), TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 3 */
	
		
		case 3:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 4                                                             ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                        	  ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                        	  ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173   				  ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20868   				  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)  To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**         Communications Microprocessor will perform a low voltage power supply");
	Print_Test_Header("**          monitor test to verify correct  operation of the low  voltage power");
	Print_Test_Header("**          supply monitors.                                                   ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_5V_LO_I stim,    ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS5V_LO_FAIL fault code      ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
			PowerUpData.TestStatus = POST_FAILED;
			
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
			(*( volatile unsigned char *)((0xC3F90600+(119)))) = 1;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 0;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS5V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 2 && Activate_Shutdown_test == 1 && (*( volatile unsigned char *)((0xC3F90600+(119)))) == 0)    /* verifying writing POST_LVPS_PSMON_POS5V_LO_FAIL code in to NVM*/
            {                                                                                 					          /* by invoking Activate_Shutdown() function */
														    	
                TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (2, TRUE, 16, testflag1, TestCaseResult);
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
			Print_Test_Case_Values (0, TRUE, 16, (*( volatile unsigned char *)((0xC3F90600+(119)))), TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 3 */
	
		case 4:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 5                                                             ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40344                        	  ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20176   				  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)To verify that If the Communications Microprocessor detects Flash "); 
    Print_Test_Header("**           Memory error, then it will write a fault message to 			  ");
	Print_Test_Header("**           NVM and failsafe the Communications Microprocessor.				  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that If the GW Microprocessor detects Flash Memory error");
	Print_Test_Header("**          then the HealthMontitor function will write a POST_FLASH_FAIL     ");
	Print_Test_Header("**          fault code to NVM and failsafe the BPCU Gateway                    ");
	Print_Test_Header("**      										                                  ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
					
			SS_TIMER_ReadDelayTimer_counter = 1;
			Activate_Shutdown_test = 0;
			POST_FLASH_TEST_flag = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 1 )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 4 */
		
		case 5:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 6                                                             ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                        	  ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20175   				  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)To verify that After coming out of a power up reset, the          "); 
    Print_Test_Header("**           Communications Microprocessor processor will perform a Flash     ");
	Print_Test_Header("**           memory check to verify the integrity of the programmed memory.    ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that The HealthMonitor function will perform a         ");
	Print_Test_Header("**          Flash memory check to verify the integrity of the programmed memory");
	Print_Test_Header("**      										                                  ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
					
			SS_TIMER_ReadDelayTimer_counter = 1;
			Activate_Shutdown_test = 0;
			POST_FLASH_TEST_flag = 2;
			RunningCheck_flag = 1; 
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (PowerUpData.Stats.FlashPassed == POST_FAILED )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (POST_FAILED, TRUE, 16, PowerUpData.Stats.FlashPassed, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 5 */

		case 6:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:7                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40342 	                          ");
	Print_Test_Header("**                                  BPCU_SWRD-40344                            ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20602                     ");
	Print_Test_Header("**                            	   		              						  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that If the Communications Microprocessor detects        "); 
    Print_Test_Header("**          RAM Memory error & Flash Memory error, then it will write a fault  ");
	Print_Test_Header("**          message  to NVM and failsafe the Communications Microprocessor.    ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**     Note:To verify that When a multi-bit ECC error is detected the          ");
	Print_Test_Header("**          HealthMonitor function will write a POST_IVOR4_ECC_FAIL fault 	  ");
	Print_Test_Header("**          code to  NVM 						                              ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 0;
			Activate_Shutdown_test = 0;
			POST_FLASH_TEST_flag = 4;
			SS_TIMER_ReadDelayTimer_counter = 1;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 1)			/*verifying writing of POST_IVOR4_ECC_FAIL code to NVM */
            {                                           /* by invoking Activate_Shutdown() function*/					
               TestCaseResult = TRUE;                   /*and performing ECC monitor test*/
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 6 */
			
			case 7:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:8                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40343                             ");
	Print_Test_Header("**   						       BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20601                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          and  RAM memory check to verify the integrity of the allocated RAM.");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that The HealthMonitor function will perform a ECC       ");
	Print_Test_Header("**          monitor test to verify correct operation of the processor's 		  ");
	Print_Test_Header("**          internal RAM and FLASH memories.                                   ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
   

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 1;
			SS_ECC_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (PowerUpData.Stats.ECCPassed == POST_FAILED)			/* performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (POST_FAILED, TRUE, 16, PowerUpData.Stats.ECCPassed , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 7 */
		
		case 8:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:9                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40343                             ");
	Print_Test_Header("**   						       BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20601                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          and  RAM memory check to verify the integrity of the allocated RAM.");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that The HealthMonitor function will perform a ECC       ");
	Print_Test_Header("**          monitor test to verify correct operation of the processor's 		  ");
	Print_Test_Header("**          internal RAM and FLASH memories.                                   ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 1;
			SS_ECC_Test_flag = 1;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (PowerUpData.Stats.ECCPassed == POST_PASSED)				/*and performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (POST_PASSED, TRUE, 16, PowerUpData.Stats.ECCPassed , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 8 */
		case 9:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:10                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-40343                            ");
	Print_Test_Header("**   						       BPCU_SWRD-40345                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40342                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40344                            ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20601                     ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20602    		          ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          and  RAM memory check to verify the integrity of the allocated RAM.");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects     "); 
    Print_Test_Header("**          RAM Memory error & Flash Memory error, then it will write a fault  ");
	Print_Test_Header("**          message to NVM and failsafe the Communications Microprocessor.     ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that													  ");
	Print_Test_Header("**          1.)The HealthMonitor function will not perform a ECC 			  ");
	Print_Test_Header("**          monitor test to verify correct operation of the processor's 		  ");
	Print_Test_Header("**          internal RAM and FLASH memories.                                   ");
	Print_Test_Header("**          2.)and When a multi-bit ECC error is detected the    		      ");
	Print_Test_Header("**          HealthMonitor function will not write a POST_IVOR4_ECC_FAIL fault  ");
	Print_Test_Header("**          code to NVM.  						                              ");
	Print_Test_Header("**          3.)if all subtests completed, selects the next test to run         ");
	Print_Test_Header("**    Note: Test Case for coverage.                                            ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			POST_ECC_TEST_counter = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( POST_ECC_TEST_counter == 1)  						/*verifying if CurrentTest selects the next test (POST_RAM_PARITY_TEST) to run*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, POST_ECC_TEST_counter, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 9 */
		case 10:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:11                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40336                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20172                     ");
	Print_Test_Header("**                                                      						  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that If the Communications Microprocessor detects a      "); 
    Print_Test_Header("**          Parity PLD error, then it will write a fault message to NVM        ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor           	      ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**     Note: When the Parity PLD test detects incorrect operation  of the      ");
	Print_Test_Header("**          parity PLD, the HealthMonitor function will write a Write a        ");
	Print_Test_Header("**          RAM_PARITY_FAULT fault code to NVM                                 ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag = 2;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 1)			/*verifying writing of POST_WDT_EARLYSTROBE_FAIL code to NVM */
            {                                           /* by invoking Activate_Shutdown() function*/					
               TestCaseResult = TRUE;                   /* failsafe the Communications Microprocessor*/
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 10 */
		
		case 11:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:12                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40337                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40341                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20171                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20177                     ");
	Print_Test_Header("**                                  					                          ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a parity PLD test to   ");
	Print_Test_Header("**          verify correct opertion of the parity PLD.					      ");
	Print_Test_Header("**          2.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**           Communications Microprocessor  will perform a watchdog early	  ");
	Print_Test_Header("**          and a late  trigger test to verify correct operation               ");
	Print_Test_Header("**           trigger test of the external watchdog timer.		              ");
	Print_Test_Header("**          					                                                  ");
	Print_Test_Header("**      Note:1.)The HealthMonitor function will perform a parity  PLD test to  ");
	Print_Test_Header("**           verify correct opertion of the parity PLD.                        ");
	Print_Test_Header("**           2.)To verify that The HealthMonitor function will perform a Warm  ");
	Print_Test_Header("**          Reset to configure the processor system to complete  tests that    ");
	Print_Test_Header("**          cause further Warm Resets.		                                  ");
	Print_Test_Header("**               Note : run the RAMParityTest (Success will causes Warm Reset) ");	
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =  4;
			POST_WDT_EARLYSTROBE_TEST_Flag = 60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			PowerUpData.Stats.RamParityPassed = POST_PASSED;
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 1)
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, testflag1, TestCaseResult);
			

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 11 */
		case 12:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:13                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40337                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40341                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40336                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20171                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20177                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20172                     ");
	Print_Test_Header("**                                  					                          ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a parity PLD test to   ");
	Print_Test_Header("**          verify correct opertion of the parity PLD.					      ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          Parity PLD error, then it will write a fault message to NVM        ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor           	      ");
	Print_Test_Header("**      Note: To verify that                                                   ");
	Print_Test_Header("**      1.)The HealthMonitor function will not perform a parity  PLD test      ");
	Print_Test_Header("**      2.)and When the Parity PLD test detects incorrect operation  of the    ");
	Print_Test_Header("**          parity PLD, the HealthMonitor function will Not write a            ");
	Print_Test_Header("**          RAM_PARITY_FAULT fault code to NVM                                 ");
	Print_Test_Header("**      3.)if all subtests completed, selects the next test to run   		  ");
	Print_Test_Header("**    Note: Test Case for coverage.                                            ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			Activate_Shutdown_test = 0;
			POST_RAM_PARITY_TEST_Flag =  11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 28;
			POST_WDT_LATESTROBE_TEST_Flag = 36;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			POST_RAM_PARITY_TEST_counter = 0;
			
			
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( POST_RAM_PARITY_TEST_counter == 1 )     /*verifying counter, if CurrentTest selects the next test (POST_WDT_EARLYSTROBE_TEST) to run*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
		
			Print_Test_Case_Values (1, TRUE, 16,  POST_RAM_PARITY_TEST_counter, TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 12 */
		case 13:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:14                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40340                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20180                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that If the Communications Microprocessor detects        "); 
    Print_Test_Header("**          watchdog timer error , then it will write a fault message to NVM   ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor.                    ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that If the WD early strobe test fails, the          	  ");
	Print_Test_Header("**          HealthMonitor  function will write a POST_WDT_EARLYSTROBE_FAIL	  ");
	Print_Test_Header("**          fault code  to NVM 				                                  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag = 11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 10;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 1)				/*verifying writing of POST_WDT_EARLYSTROBE_FAIL code to NVM */
            {												/* by invoking Activate_Shutdown() function*/						
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 13 */
		
		case 14:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:15                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40341                            ");
    Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-20178                      ");
	Print_Test_Header("**                            	     		             					  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
   	Print_Test_Header("**          To verify that After coming out of a power up reset, the           "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger ");
	Print_Test_Header("**           test and a late  trigger test to verify correct operation          ");
	Print_Test_Header("**          of the external watchdog timer.				                      ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**     Note:To verify that,The HealthMonitor function will test the Watchdog    ");
	Print_Test_Header("**          early trigger time of less than 3 ms as configured by hardware      ");
	Print_Test_Header("**          strapping.                                                         ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag=11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 14;
			SS_WD_Test_flag = 0;
			waitCount_global = 1;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_WD_Test_flag == 1 && waitCount_global == 264000)  /* verifying Watchdog early trigger   */
            {														 /* time of less than 3 ms by getting the wait count */
               TestCaseResult = TRUE;							     /*  from the function SS_WD_Test()  */
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, SS_WD_Test_flag, TestCaseResult);
			Print_Test_Case_Values (264000, TRUE, 16, waitCount_global, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 14 */
		
		case 15:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:16                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40340                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40341                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20180                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20178                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that If the Communications Microprocessor detects     "); 
    Print_Test_Header("**          watchdog timer error , then it will write a fault message to NVM and");
	Print_Test_Header("**          failsafe the Communications Microprocessor                          ");
    Print_Test_Header("**          2.)To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger ");
	Print_Test_Header("**          test and a late  trigger test to verify correct operation           ");
	Print_Test_Header("**          of the external watchdog timer.				                       ");
	Print_Test_Header("**      Note: To verify that   					                               ");	
	Print_Test_Header("**     	 1.)If the WD early strobe test fails, the HealthMonitor function will ");
	Print_Test_Header("**           not write a POST_WDT_EARLYSTROBE_FAIL fault code  to NVM.		   ");
	Print_Test_Header("**        2.)The HealthMonitor function will not test the Watchdog early 	   ");
	Print_Test_Header("**           trigger time of less than 3 ms.     							   ");
	Print_Test_Header("**     	 3.)verify if all subtests complete,select the next test to run.       ");
	Print_Test_Header("**       Note:   This TC is for coverage                                        ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 18;
			Activate_Shutdown_test = 0;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_WDT_EARLYSTROBE_TEST_counter =0;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( POST_WDT_EARLYSTROBE_TEST_counter == 1)		/*verifying counter, if CurrentTest selects the */ 
            {													/*next test (POST_WDT_LATESTROBE_TEST) to run*/										
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			
			Print_Test_Case_Values (1, TRUE, 16, POST_WDT_EARLYSTROBE_TEST_counter, TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 15 */
		
		case 16:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:17                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40340                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20870                     ");
	Print_Test_Header("**                                                          					  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that If the Communications Microprocessor detects 	      "); 
    Print_Test_Header("**          watchdog timer error, then it will write a fault message to NVM    ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor.   				  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: If the WD late strobe test fails, the HealthMonitor function will  ");
	Print_Test_Header("**          write a POST_WDT_LATESTROBE_FAIL fault code to NVM 				  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 19;
			POST_WDT_LATESTROBE_TEST_Flag = 25;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 1)					/*verifying writing of POST_WDT_LATESTROBE_FAIL code to NVM */
            {                                                   /* by invoking Activate_Shutdown() function*/					
               TestCaseResult = TRUE;                         
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, Activate_Shutdown_test, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 16 */
		case 17:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:18                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40341                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20179                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that After coming out of a power up reset, the           "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger");
	Print_Test_Header("**          test and a late  trigger test to verify correct operation          ");
	Print_Test_Header("**           of the external watchdog timer.					                  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that,The HealthMonitor function will test the Watchdog   ");
	Print_Test_Header("**           late trigger time of greater than 7 ms as configured by hardware  ");
	Print_Test_Header("**           strapping.                                                        ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 19;
			POST_WDT_LATESTROBE_TEST_Flag = 30;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			waitCount_global = 1;
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_WD_Test_flag== 1 && waitCount_global == 1056000) 	/* verifying Watchdog late trigger   */
            {                                                           /* time  of greater than 7 ms by getting the wait count */
               TestCaseResult = TRUE;                                   /*  from the function SS_WD_Test()  */
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, SS_WD_Test_flag, TestCaseResult);
			Print_Test_Case_Values (1056000, TRUE, 16, waitCount_global, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 17 */
		
		case 18:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:19                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40341                            ");
	Print_Test_Header("**  								   BPCU_SWRD-40340                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20179                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20870                     ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that After coming out of a power up reset, the           "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger");
	Print_Test_Header("**          test and a late  trigger test to verify correct operation          ");
	Print_Test_Header("**           of the external watchdog timer.					                  ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects 	  "); 
    Print_Test_Header("**          watchdog timer error, then it will write a fault message to NVM    ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor                	  ");
	Print_Test_Header("**      Note: To verify that				                                      ");	
	Print_Test_Header("**          1.)The HealthMonitor function will not test the Watchdog late 	  ");
	Print_Test_Header("**             trigger time of greater than 7 ms .    						  ");
	Print_Test_Header("**    	   2.)If the WD late strobe test fails, the HealthMonitor function    ");
	Print_Test_Header("**             will not write a POST_WDT_LATESTROBE_FAIL fault code to NVM	  ");
	Print_Test_Header("**          3.)verify if all subtests complete clear out all powerup data.     ");
	Print_Test_Header("**      Note: This TC is for coverage                                          ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 20;
			POST_WDT_LATESTROBE_TEST_Flag = 40;
			Activate_Shutdown_test = 0;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( PowerUpData.InPOST == SS_FALSE)    										/*verifying if all subtests complete*/
            {																				/*clear out all powerup data*/		
               TestCaseResult = TRUE;														/*can not define value other than expected */
            }																				/*for PowerUpData.InPOST as its getting TRUE value from */	
            else																			/*stub in 2nd occurance of while loop*/	
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			
			Print_Test_Case_Values (SS_FALSE, TRUE, 16,PowerUpData.InPOST, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 18 */
		
		case 19:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:20                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20198                     ");
	Print_Test_Header("**                                                          					  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: )To verify that,At completion of all warm start HealthMonitor tests");
	Print_Test_Header("**           a cold reset will  be performed to provide the cold start condition");
	Print_Test_Header("**          for CDN initialization.                             	 	          ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_COLDRESET_flag = 55;
			POST_RAM_PARITY_TEST_Flag =60;
			POST_WDT_EARLYSTROBE_TEST_Flag = 60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			VerifiedStoreEventCode_Test_flag = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (VerifiedStoreEventCode_Test_flag == EC_POST_COLDRESET_IN_PROCESS)	/* causes cold reset to start the Gateway */				
            {                                                  						/* if first try or previous failure */
               TestCaseResult = TRUE;                         						/* store in NVM COLDRESET in process */
            }																		/* config system for cold reset */
            else																	 /* delay to insure single reset occurs */
            {																		 /* create cold reset */	
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (EC_POST_COLDRESET_IN_PROCESS, TRUE, 16, VerifiedStoreEventCode_Test_flag, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 19 */
		case 20:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:21                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20198                     ");
	Print_Test_Header("**                                                          					  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that,At completion of all warm start HealthMonitor tests ");
	Print_Test_Header("**          a cold reset will  be performed to provide the cold start condition");
	Print_Test_Header("**          for CDN initialization.                             	 	          ");
	Print_Test_Header("**    Note:verifying TRUE of if(EventCode() == (EC_POST_COLDRESET_COMPLETE))   ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			
			POST_RAM_PARITY_TEST_Flag =60;
			POST_WDT_EARLYSTROBE_TEST_Flag = 60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			POST_COLDRESET_flag = 65;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			EventCode_Val = 1;
			VerifiedStoreEventCode_Test_flag = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (VerifiedStoreEventCode_Test_flag == EC_ALL_EVENTS_CLEAR)   /* checking NVM event for COLDRESET complete */
            {                                                        
               TestCaseResult = TRUE;                                   
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
		
			Print_Test_Case_Values (EC_ALL_EVENTS_CLEAR, TRUE, 16, VerifiedStoreEventCode_Test_flag, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 20 */
		
		case 21:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:22                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20198                     ");
	Print_Test_Header("**                                                          					  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that,At completion of all warm start HealthMonitor tests ");
	Print_Test_Header("**           a cold reset will  be performed to provide the cold start condition");
	Print_Test_Header("**          for CDN initialization.                             	 	           ");
	Print_Test_Header("**    Note:verifying FALSE of  if(EventCode() == (EC_POST_COLDRESET_COMPLETE))  ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =60;
			POST_WDT_EARLYSTROBE_TEST_Flag = 60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			Activate_Shutdown_test = 0;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			POST_COLDRESET_flag = 65;
			EventCode_Val = 0;
			VerifiedStoreEventCode_Test_flag = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( VerifiedStoreEventCode_Test_flag == 0)    	 /* checking NVM event for COLDRESET not complete */								
            {																				
               TestCaseResult = TRUE;														
            }																				
            else																			
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			
			Print_Test_Case_Values (0, TRUE, 16,VerifiedStoreEventCode_Test_flag, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 21 */
		
		case 22:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:23                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40337                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40336                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20171                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20172                     ");
	Print_Test_Header("**                                  					                          ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a parity PLD test to   ");
	Print_Test_Header("**          verify correct opertion of the parity PLD.					      ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          Parity PLD error, then it will write a fault message to NVM        ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor           	      ");
	Print_Test_Header("**      Note: To verify that                                                   ");
	Print_Test_Header("**      1.)The HealthMonitor function will not perform a parity  PLD test      ");
	Print_Test_Header("**      2.)and When the Parity PLD test detects incorrect operation  of the    ");
	Print_Test_Header("**          parity PLD, the HealthMonitor function will Not write a            ");
	Print_Test_Header("**          RAM_PARITY_FAULT fault code to NVM                                 ");
	Print_Test_Header("**      3.)if all subtests completed, selects the next test to run   		  ");
	Print_Test_Header("**    Note: Test Case for coverage.                                            ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			Activate_Shutdown_test = 0;
			POST_RAM_PARITY_TEST_Flag = 25;
			POST_WDT_EARLYSTROBE_TEST_Flag = 35;
			POST_WDT_LATESTROBE_TEST_Flag = 45;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( Activate_Shutdown_test == 0)
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16,  Activate_Shutdown_test, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 22*/
		
		case 23:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:24                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                        	  ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                        	  ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173   				  ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20867   				  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)  To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor will perform a low voltage power supply");
	Print_Test_Header("**          monitor test to verify correct  operation of the low  voltage power");
	Print_Test_Header("**          supply monitors.                                                   ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_3R3V_LO_I stim,  ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS3R3V_LO_FAIL fault code    ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**       Note : This TC is for MCDC Coverage                                   ");
    Print_Test_Header("******************************************************************************/");


            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_FAILED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = 7;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 0 )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 23 */
		case 24:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:25                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40337                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40341                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40336                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20171                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20177                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20172                     ");
	Print_Test_Header("**                                  					                          ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a parity PLD test to   ");
	Print_Test_Header("**          verify correct opertion of the parity PLD.					      ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          Parity PLD error, then it will write a fault message to NVM        ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor           	      ");
	Print_Test_Header("**      Note: To verify that                                                   ");
	Print_Test_Header("**      1.)The HealthMonitor function will not perform a parity  PLD test      ");
	Print_Test_Header("**      2.)and When the Parity PLD test detects incorrect operation  of the    ");
	Print_Test_Header("**          parity PLD, the HealthMonitor function will Not write a            ");
	Print_Test_Header("**          RAM_PARITY_FAULT fault code to NVM                                 ");
	Print_Test_Header("**      3.)if all subtests completed, selects the next test to run   		  ");
	Print_Test_Header("**    Note:1.) TestCase added for MCDC Coverage								  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			
			SS_TIMER_ReadDelayTimer_counter = 0;
			POST_FLASH_TEST_flag = 10;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
						
            /* function under test invocation */
            RAMParityTest(LVPS_PSMON_POS3R3V_LO);

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( SS_TIMER_ReadDelayTimer_counter == 1)
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16,  SS_TIMER_ReadDelayTimer_counter, TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 24 */
		case 25:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:26                                                               ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40337                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40341                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40336                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20171                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20177                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20172                     ");
	Print_Test_Header("**                                  					                          ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a parity PLD test to   ");
	Print_Test_Header("**          verify correct opertion of the parity PLD.					      ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          Parity PLD error, then it will write a fault message to NVM        ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor           	      ");
	Print_Test_Header("**      Note: To verify that                                                   ");
	Print_Test_Header("**      1.)The HealthMonitor function will not perform a parity  PLD test      ");
	Print_Test_Header("**      2.)and When the Parity PLD test detects incorrect operation  of the    ");
	Print_Test_Header("**          parity PLD, the HealthMonitor function will Not write a            ");
	Print_Test_Header("**          RAM_PARITY_FAULT fault code to NVM                                 ");
	Print_Test_Header("**      3.)if all subtests completed, selects the next test to run   		  ");
	Print_Test_Header("**    Note: This TC is for Coverage for false of	below condition               ");
	Print_Test_Header("**         if(++PowerUpData.CurrentSubtest >= TOTAL_MEMORY_PARITY_SUBTESTS)    ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("******************************************************************************/");
   

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 4;
			SS_ECC_Test_flag = 0;
			POST_FLASH_TEST_flag = 10;
			SS_TIMER_ReadDelayTimer_counter = 1;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS5V_HI;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_ECC_Test_flag == 0)			/* performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, SS_ECC_Test_flag , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 25*/
		case 26:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:27                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: None				                      	  ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173   				  ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
	Print_Test_Header("**      							                                              ");	
	Print_Test_Header("**   	    To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**      Note:testcase added for MCDC coverage for first if condition           ");
	Print_Test_Header("**      		  HealthMonitor function										  ");
    Print_Test_Header("******************************************************************************/");


            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 25;														/*to check True False of first if of HealthMonitor Function*/
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_FAILED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = 7;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Activate_Shutdown_test == 0 )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 26 */
		case 27:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:28                                                              ");
    Print_Test_Header("**                                                                             ");
   Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                        	  ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20175   				  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)To verify that After coming out of a power up reset, the          "); 
    Print_Test_Header("**           Communications Microprocessor processor will perform a Flash      ");
	Print_Test_Header("**           memory check to verify the integrity of the programmed memory.    ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that The HealthMonitor function will not perform a      ");
	Print_Test_Header("**          Flash memory check to verify the integrity of the programmed memory");
	Print_Test_Header("**        2.)verify if all subtests complete clear out all powerup data.       ");
    Print_Test_Header("**    Note: This TC is for MCDC coverage of below condition                    ");
	Print_Test_Header("**    		if(++PowerUpData.CurrentSubtest >= TOTAL_FLASH_SUBTESTS)          ");
	Print_Test_Header("**      										                                  ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
					
			SS_TIMER_ReadDelayTimer_counter = 1;
			Activate_Shutdown_test = 0;
			POST_FLASH_TEST_flag = 14;
			RunningCheck_flag = 0; 
			
			POST_RAM_PARITY_TEST_Flag = 60;
			POST_WDT_EARLYSTROBE_TEST_Flag =60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			Flag = 0;
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Flag == 0 && Activate_Shutdown_test == 0)
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, Flag, TestCaseResult);
			Print_Test_Case_Values (0, TRUE, 16, Activate_Shutdown_test, TestCaseResult);
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 27 */
		case 28:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:29                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-40343                             ");
	Print_Test_Header("**   						       BPCU_SWRD-40345                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40342                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40344                            ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20601                     ");
	Print_Test_Header("**                            	   787_GW_BPCU_SWDD-20602    		          ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          and  RAM memory check to verify the integrity of the allocated RAM.");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects     "); 
    Print_Test_Header("**          RAM Memory error & Flash memory error, then it will write a  	  ");
	Print_Test_Header("**          fault message to NVM and failsafe the Communications Microprocessor.");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: To verify that													  ");
	Print_Test_Header("**          1.)The HealthMonitor function will not perform a ECC 			  ");
	Print_Test_Header("**          monitor test to verify correct operation of the processor's 		  ");
	Print_Test_Header("**          internal RAM and FLASH memories.                                   ");
	Print_Test_Header("**          2.)and When a multi-bit ECC error is detected the    		      ");
	Print_Test_Header("**          HealthMonitor function will not write a POST_IVOR4_ECC_FAIL fault  ");
	Print_Test_Header("**          code to NVM.  						                              ");
	Print_Test_Header("**          3.)if all subtests completed, selects the next test to run         ");
	Print_Test_Header("**    Note:  Test Case for fasle of coverage for below condition.              ");
	Print_Test_Header("**       if(++PowerUpData.CurrentSubtest >= TOTAL_ECC_SUBTESTS)                ");
    Print_Test_Header("******************************************************************************/");
   

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag2 = 6;
			POST_RAM_PARITY_TEST_Flag =11;
			POST_WDT_EARLYSTROBE_TEST_Flag = 20;
			POST_WDT_LATESTROBE_TEST_Flag = 35;
			SS_ECC_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_ECC_Test_flag == 0)			/* performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, SS_ECC_Test_flag , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 28 */
		case 29:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:30                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40340                            ");
	Print_Test_Header("**   							   BPCU_SWRD-40341                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20180                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20178                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that If the Communications Microprocessor detects     "); 
    Print_Test_Header("**          watchdog timer error , then it will write a fault message to NVM and");
	Print_Test_Header("**          failsafe the Communications Microprocessor. 						  ");
    Print_Test_Header("**          2.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger");
	Print_Test_Header("**           test and a late  trigger test to verify correct operation         ");
	Print_Test_Header("**          of the external watchdog timer.				                      ");
	Print_Test_Header("**      Note: To verify that   					                              ");	
	Print_Test_Header("**     	 1.)If the WD early strobe test fails, the HealthMonitor function will");
	Print_Test_Header("**           not write a POST_WDT_EARLYSTROBE_FAIL fault code  to NVM.		  ");
	Print_Test_Header("**        2.)The HealthMonitor function will not test the Watchdog early 	  ");
	Print_Test_Header("**           trigger time of less than 3 ms.     							  ");
	Print_Test_Header("**     	 3.)verify if all subtests complete,select the next test to run.      ");
	Print_Test_Header("**    Note: This TC is for MCDC coverage of below condition                    ");
	Print_Test_Header("**    		if(++PowerUpData.CurrentSubtest >= TOTAL_WDT_SUBTESTS)            ");
    Print_Test_Header("******************************************************************************/");
   

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag2 = 7;
			SS_ECC_Test_flag = 0;
			POST_FLASH_TEST_flag = 10;
			SS_TIMER_ReadDelayTimer_counter = 1;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS5V_HI;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_ECC_Test_flag == 0)			/* performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, SS_ECC_Test_flag , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 29 */
		case 30:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:31                                                              ");
    Print_Test_Header("**                                                                             ");
     Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40341                            ");
	Print_Test_Header("**  								   BPCU_SWRD-40340                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20179                     ");
	Print_Test_Header("**                                  787_GW_BPCU_SWDD-20870                     ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          To verify that After coming out of a power up reset, the           "); 
    Print_Test_Header("**          Communications Microprocessor will perform a watchdog early trigger");
	Print_Test_Header("**           test  and a late  trigger test to verify correct operation        ");
	Print_Test_Header("**           of the external watchdog timer.					                  ");
	Print_Test_Header("**          2.)To verify that If the Communications Microprocessor detects 	  "); 
    Print_Test_Header("**          watchdog timer error, then it will write a fault message to NVM    ");
	Print_Test_Header("**          and failsafe the Communications Microprocessor                	  ");
	Print_Test_Header("**      Note: To verify that				                                      ");	
	Print_Test_Header("**          1.)The HealthMonitor function will not test the Watchdog late 	  ");
	Print_Test_Header("**             trigger time of greater than 7 ms .    						  ");
	Print_Test_Header("**    	   2.)If the WD late strobe test fails, the HealthMonitor function    ");
	Print_Test_Header("**             will not write a POST_WDT_LATESTROBE_FAIL fault code to NVM	  ");
	Print_Test_Header("**          3.)verify if all subtests complete clear out all powerup data.     ");
    Print_Test_Header("**    Note: This TC is for MCDC coverage of below condition                    ");
	Print_Test_Header("**    		   if(++PowerUpData.CurrentSubtest >= TOTAL_WDT_SUBTESTS)         ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag2 = 8;
			SS_ECC_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;
			/***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS5V_HI;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (SS_ECC_Test_flag == 0)			/* performing ECC monitor test*/
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (0, TRUE, 16, SS_ECC_Test_flag , TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS   */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 30 */
		case 31:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:32                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173                     ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**            To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor will perform a low voltage power     ");
	Print_Test_Header("**          supply monitor test to verify correct operation of the low  		  ");
	Print_Test_Header("**          svoltage power upply monitors.                                     ");	
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**      Note:testcase added for MCDC coverage for default case of first switch");
	Print_Test_Header("**      		  HealthMonitor function										  ");
	Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			BT_WD_Reset_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_FAILED;
			PowerUpData.CurrentTest = 7;
			PowerUpData.CurrentSubtest = 9;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (BT_WD_Reset_flag == 1 )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GCU_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (1, TRUE, 16, BT_WD_Reset_flag, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 31 */
		case 32:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 33                                                             ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                        	  ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20175   				  ");
	Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.)To verify that After coming out of a power up reset, the          "); 
    Print_Test_Header("**           Communications Microprocessor processor will perform a Flash     ");
	Print_Test_Header("**           memory check to verify the integrity of the programmed memory.    ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that The HealthMonitor function will perform a         ");
	Print_Test_Header("**          Flash memory check to verify the integrity of the programmed memory");
	Print_Test_Header("**      Note:This TC is for MCDC coverage of below condition.   				  ");
	Print_Test_Header("**       TRUE of if(RunningCheck != *(SS_U32 *)APP_CRC_ADDR) in below   		  ");
	Print_Test_Header("**      	 case POST_FLASH_TEST:												  ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
					
			SS_TIMER_ReadDelayTimer_counter = 1;
			Activate_Shutdown_test = 0;
			POST_FLASH_TEST_flag = 2;
			RunningCheck_flag = 0; 
			
			POST_RAM_PARITY_TEST_Flag = 60;
			POST_WDT_EARLYSTROBE_TEST_Flag =60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			POST_COLDRESET_flag = 60;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			Flag = 0;
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (Flag == 20 )
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (20, TRUE, 16, Flag, TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to  IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 32 */
		
		
		case 33:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case:34                                                              ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40345                            ");
	Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20198                     ");
	Print_Test_Header("**                                                          					  ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**          1.)To verify that After coming out of a power up reset, the        "); 
    Print_Test_Header("**          Communications Microprocessor  will perform a Flash memory check   ");
	Print_Test_Header("**          to verify the integrity of the programmed memory.				  ");
	Print_Test_Header("**          					                                                  ");	
	Print_Test_Header("**    Note: At completion of all warm start HealthMonitor tests  a cold reset  ");
	Print_Test_Header("**          will be performed to provide the cold start condition   		  	  ");
	Print_Test_Header("**          for CDN initialization.                             	 	          ");
	Print_Test_Header("**   Note: This TC is for MCDC coverage of FALSE of below condition	          ");
	Print_Test_Header("**         if(++PowerUpData.CurrentSubtest >= TOTAL_COLDRESETS) 	 	          ");
	Print_Test_Header("**         of Case POST_COLDRESET: 						      			      ");
    Print_Test_Header("******************************************************************************/");
	
            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
						
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			testflag2 = 2;
			POST_RAM_PARITY_TEST_Flag =60;
			POST_WDT_EARLYSTROBE_TEST_Flag = 60;
			POST_WDT_LATESTROBE_TEST_Flag = 60;
			Activate_Shutdown_test = 0;
			SS_WD_Test_flag = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 4;
			POST_COLDRESET_flag = 75;
			EventCode_Val = 0;
			VerifiedStoreEventCode_Test_flag = 0;
            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 2;
			PowerUpData.TestStatus = POST_PASSED;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = LVPS_PSMON_POS3R3V_LO;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if ( VerifiedStoreEventCode_Test_flag == 0)    						/* Verifying if COLDRESET is not complete*/			
            {																				
               TestCaseResult = TRUE;														
            }																				
            else																			
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			
			Print_Test_Case_Values (0, TRUE, 16,VerifiedStoreEventCode_Test_flag, TestCaseResult);
                /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);
			
            /*Increment the test case number to point to the following test case */
            TestCase++;

            /* Status is set to  IN_PROGRESS  */
            Status = IN_PROGRESS;

            break;
        }/* end of Case 33 */			
			
			
        case 34:
        {
    Print_Test_Header("/******************************************************************************");
    Print_Test_Header("**   Test Case: 35                                                             ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-40339                            ");
	Print_Test_Header("**                                  BPCU_SWRD-40338                            ");
    Print_Test_Header("**                            SWDD: 787_GW_BPCU_SWDD-20173                     ");
    Print_Test_Header("**                                  787_GW_BPCU_SWDD-20869                     ");
    Print_Test_Header("**   Normal/robustness test: Normal                                            ");
    Print_Test_Header("**                                                                             ");
    Print_Test_Header("**     Objective:                                                              ");
    Print_Test_Header("**        1.) To verify that After coming out of a power up reset, the         "); 
    Print_Test_Header("**          Communications Microprocessor will perform a low voltage power     ");
	Print_Test_Header("**          supply monitor test to verify correct operation of the low  	      ");
	Print_Test_Header("**          voltage power upply monitors.                                      ");	
	Print_Test_Header("**        2.)  To verify that If the Communications Microprocessor detects a   "); 
    Print_Test_Header("**          low voltage power supply monitor error, then it will write a fault ");
	Print_Test_Header("**         message to NVM and failsafe the Communications Microprocessor.	  ");
	Print_Test_Header("**                                                                             ");
	Print_Test_Header("**       Note:					                                              ");	
	Print_Test_Header("**   	 1.)To verify that HealthMonitor function will perform a low voltage  ");
	Print_Test_Header("**          power supply monitor test to verify correct operation of the low   ");
	Print_Test_Header("**          voltage power supply monitors.                                     ");
	Print_Test_Header("**   	 2.)To verify that If the HealthMonitor function detects a low voltage");
	Print_Test_Header("**          power supply monitor error on the PS_MON_STIM_POS_5V_HI_I stim,    ");
	Print_Test_Header("**          then it will write a POST_LVPS_PSMON_POS5V_HI_FAIL fault code      ");
	Print_Test_Header("**          to NVM                                                             ");
	Print_Test_Header("**        This test case for coverage purpose only                             ");
    Print_Test_Header("******************************************************************************/");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;   
			
			/*reset the values*/
			PowerUpData.TestStatus = POST_FAILED;
			
            /* Initialize the expected variable values */
			testflag = 0;
			testflag1 = 0;
			Activate_Shutdown_test = 0;
			SS_TIMER_ReadDelayTimer_counter = 1;
			POST_FLASH_TEST_flag = 10;

            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Set the test variables for the test case*/
			PowerUpData.TotalTestRuns = 0;
			PowerUpData.CurrentTest = POST_LVPS_TEST;
			PowerUpData.CurrentSubtest = 4;
			
            /* function under test invocation */
            ssx_HealthMonitor();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Expected and Actual values comparison */
		
            if (testflag1 == 4) 
            {
               TestCaseResult = TRUE;
            }
            else
            {
               Failcount++;
            }

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_APP_ssx_healthmonitor_Per_Func.c");

            /* print the expected and actual valu;es in the result file */
			Print_Test_Case_Values (4, TRUE, 16, testflag1, TestCaseResult);

                
                
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

            /*Increment the test case number to point to the following test case */
            TestCase++;			


            /* Status is set to COMPLETED  */
            Status = COMPLETED;

            break;
        }/* end of Case 34 */

		
	}/* end of switch */
	
    /* Return the Status */
    return Status;

}		
        

/********END of GW_APP_ssx_healthmonitor_Per_Func.c *************/
