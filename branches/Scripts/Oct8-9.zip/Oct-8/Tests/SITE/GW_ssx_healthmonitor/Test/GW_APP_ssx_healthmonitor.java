
package tIO_Unit_Test;

import junit.framework.Test;

import org.eclipse.hyades.test.common.junit.DefaultTestArbiter;
import org.eclipse.hyades.test.common.junit.HyadesTestCase;
import org.eclipse.hyades.test.common.junit.HyadesTestSuite;
import comms.*;
import IO_Unit_Test.IO_Unit_Test;
import Products.PRODUCT_787_EPGS_MT;

public class GW_APP_ssx_healthmonitor extends HyadesTestCase {
	 /**
     
     * TestScriptheader
     * @throws Exception
     */
    public void testScriptheader() throws Exception

        

    {
        String name1 =        CommUtil.Convert.Trim("$RCSfile: GW_APP_ssx_healthmonitor.java $");
        String name =        name1.replace("$", " ");
        String version1 =     CommUtil.Convert.Trim("$Revision: 1.2 $");
        String version =     version1.replace("$", " ");
    	

        /***********************************************************************\n"+
        "**                                                                     \n"+
        "**                                  WARNING                            \n"+
        "**                                                                     \n"+
        "**  Copyright � Hamilton Sundstrand Corporation. This document is the  \n"+
        "**  property of Hamilton Sundstrand Corporation (HS). You may not      \n"+
        "**  possess,use, copy or disclose this document or any information     \n"+
        "**  in it, for any purpose, including without limitation, to design,   \n"+
        "**  manufacture or repair parts, or obtain any government approval to  \n"+
        "**  do so, without HSC's express written permission. Neither receipt   \n"+
        "**  nor possession of this document alone, from any source,            \n"+
        "**  constitutes such permission. Possession, use, copying or           \n"+
        "**  disclosure by anyone without HSC's express written permission is   \n"+
        "**  not authorized and may result in criminal and/or civil liability.  \n"+
        "**                                                                     \n"+*/       

                Logger.println("\n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "**                                                                     \n"+
                "**                                                                     \n"+
                "**   Test Identification: GW_APP_ssx_healthmonitor.java                \n"+
                "**                                                                     \n"+
                "**   This file's version information::                                 \n"+
                "**                 $RCSfile: GW_APP_ssx_healthmonitor.java $                                        \n"+
                "**                 $Revision: 1.2 $                                       \n"+
                "**                                                                     \n"+
                "**   Results generated from following Test Script:                     \n"+
                "**            "+name+"                                                 \n"+
                "**            "+version+"                                              \n"+
                "**                                                                     \n"+
                "**  Software Configuration Index (SCI): DS10596/224                    \n"+
                "**                                                                     \n"+
                "**                                                                     \n"+
                "**   Software Level: A                                                 \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "**      Author(s):  Anuradha	                                        \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**                           History                                   \n"+
                "**                                                                     \n"+
                "**    Date        Initials      Problem Description                    \n"+
                "**   28/11/12      AD       Initial version          				    \n"+
                "**   07/12/12      AD       Updated for Review comments     		    \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "**     Test Support Environment:DS10596/225                            \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "**     Requirements Tested: SWRD : BPCU_SWRD-40338                     \n"+
                "**                          		BPCU_SWRD-40339 			        \n"+
                "**                          		BPCU_SWRD-40336                     \n"+
                "**                          		BPCU_SWRD-40337  			        \n"+
                "**                          		BPCU_SWRD-40341 			        \n"+ 
                "**                          		BPCU_SWRD-40342						\n"+
                "**                          		BPCU_SWRD-40340						\n"+
                "**                          		BPCU_SWRD-40343						\n"+
                "**                          		BPCU_SWRD-40345						\n"+
                "**                          											\n"+
                "**                          SWDD : 787_GW_BPCU_SWDD-20174				\n"+
                "**                          		787_GW_BPCU_SWDD-20173				\n"+
				"**                          		787_GW_BPCU_SWDD-20867				\n"+
                "**                          		787_GW_BPCU_SWDD-20869				\n"+
                "**                          		787_GW_BPCU_SWDD-20868				\n"+
                "**                          		787_GW_BPCU_SWDD-20172				\n"+
				"**                          		787_GW_BPCU_SWDD-20171				\n"+
			    "**                          		787_GW_BPCU_SWDD-20177     			\n"+
				"**                          		787_GW_BPCU_SWDD-20178				\n"+
				"**                          		787_GW_BPCU_SWDD-20179				\n"+
				"**                             	787_GW_BPCU_SWDD-20870				\n"+                              
				"**                             	787_GW_BPCU_SWDD-20176				\n"+
                "**                             	787_GW_BPCU_SWDD-20198        	    \n"+
                "**                             	787_GW_BPCU_SWDD-20601         	   \n"+
				"**                                	787_GW_BPCU_SWDD-20602				\n"+
				"**                                	787_GW_BPCU_SWDD-20180				\n"+
				"**                                                                     \n"+                           
				"**                                                                     \n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "** Units Tested:  ssx_healthmonitor.c                                   \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**                                                                     \n"+
                "** Assumptions and Constraints:  None                                  \n"+
                "**                                                                     \n"+
                "***********************************************************************\n"+
                "**     Criteria for Evaluating Results:                                \n"+
                "**                                                                     \n"+
                "**     All data listed under Expected Outputs must exactly match       \n"+
                "**     the listed result or range expressed.                           \n"+
                "**                                                                     \n"+
                "***********************************************************************");
    }
	
 
	 /**
	 *  Initialization of the variables.
	 */
    public static CommsPortTLP comms=null;
    public static PRODUCT_787_EPGS_MT unit=null;

    static IO_Unit_Test Unit_Test = null;
    String ClassName              = "GW_APP_ssx_healthmonitor";
    String Cov_File_Name          = "GW_APP_ssx_healthmonitor";
    String ClassName1              = "ssx_healthmonitor";

    /*Getting the Current working directory */
    String curDir       = System.getProperty("user.dir");
    String Cov_FilePath =  curDir + "\\SITE_Test_Results\\" + ClassName1 + ".tio";


	/**
	 * Constructor for NonInstrumented_BITE_Execution.
	 * @param name
	 */
	public GW_APP_ssx_healthmonitor(String name)
	{
		super(name);
	}

	/**
	 * Returns the JUnit test suite that implements the <b>tIO_Unit_Test_2</b> definition.
	 */
	public static Test suite() {
		HyadesTestSuite GW_APP_ssx_healthmonitor = new HyadesTestSuite("GW_APP_ssx_healthmonitor");
		GW_APP_ssx_healthmonitor.setArbiter(DefaultTestArbiter.INSTANCE).setId(
				"A1DFC15E62293AC0ED02E33939393433");
		GW_APP_ssx_healthmonitor.addTest(new GW_APP_ssx_healthmonitor("testHeader").setId(
				"A1DFC15E668E90B0ED02E33939393433").setTestInvocationId(
				"A1DFC15E734013B0ED02E33939393433"));
		GW_APP_ssx_healthmonitor.addTest(new GW_APP_ssx_healthmonitor("testScriptheader").setId(
		"A1DFC15E668E90B0ED02E33939393433").setTestInvocationId(
		"A1DFC15E734013B0ED02E33939393433"));
		GW_APP_ssx_healthmonitor.addTest(new GW_APP_ssx_healthmonitor("tC1").setId(
				"A1DFC15E6AC8DF00ED02E33939393433").setTestInvocationId(
				"A1DFC15E73498990ED02E33939393433"));		
		GW_APP_ssx_healthmonitor.addTest(new GW_APP_ssx_healthmonitor("testFooter").setId(
				"A1DFC15E6CD306E0ED02E33939393433").setTestInvocationId(
				"A1DFC15E734E6B90ED02E33939393433"));
		return GW_APP_ssx_healthmonitor;
	}

	/**
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception
	{
	}

	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception
	{
	}

	
	
	
	/**
	 * test Header
	 * @throws Exception
	 */
	public void testHeader() throws Exception
	{
		// To get the current working Directory.
		String curDir = System.getProperty("user.dir");
		String strClsName = "GW_APP_ssx_healthmonitor";
		String CovRsltFileName = curDir + "\\SITE_Test_Results\\" + ClassName1 + ".tio";
		String strRsltFileName = curDir+"\\SITE_Test_Results\\"+ strClsName;

		comms = new CommsPortTLP();
		unit = new PRODUCT_787_EPGS_MT(comms, strRsltFileName + ".res", CovRsltFileName, strClsName);
		
		System.out.println(unit.getSiteVersion());
	}

	/*
    Executes all the BITE test scripts
    */
	public void tC1() throws Exception
	{
		/* Call BITE test scripts */
		unit.Execute_TestGroups((byte)GlobalDataUT.TEST_NAME.GW_APP_ssx_healthmonitor_Per_Func.ordinal());
			}

	/**
	 * Test footer
	 * @throws Exception
	 */
	public void testFooter() throws Exception
	{
		/* Close the CSCI connection */
		unit.CSCI_Close();
	}
}
