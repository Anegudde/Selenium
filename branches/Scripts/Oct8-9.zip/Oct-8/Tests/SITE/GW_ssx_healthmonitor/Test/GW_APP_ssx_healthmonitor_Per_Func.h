/****************************************************************************
**
**                                 WARNING
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
****************************************************************************
**
** Test Identification: GW_APP_ssx_healthmonitor_Per_Func.h
**
** This file's version information::
** $RCSfile: GW_APP_ssx_healthmonitor_Per_Func.h $
** $Revision: 1.2 $
**
** Software Configuration Index (SCI): DS10596/224
**
** Software Level: A
**
*****************************************************************************
**
** Author(s): Anuradha
**
******************************************************************************
**
**                                 History
**
**        Date        Initials     Description
**
**        28/11/12      AD       Initial version
**        07/12/12      AD       Updated for Review comments
******************************************************************************
**
** Test Support Environment: DS10596/225
**
*****************************************************************************
**
** Requirements Tested: SWRD : 	BPCU_SWRD-40338
**                      		BPCU_SWRD-40339
**                      		BPCU_SWRD-40336
**                      		BPCU_SWRD-40337
**                      		BPCU_SWRD-40341
**                      		BPCU_SWRD-40342
**                      		BPCU_SWRD-40340
**                      		BPCU_SWRD-40343
**                      		BPCU_SWRD-40345
**                      
**                      SWDD : 	787_GW_BPCU_SWDD-20174
**                      		787_GW_BPCU_SWDD-20173
**                      		787_GW_BPCU_SWDD-20867
**                      		787_GW_BPCU_SWDD-20869
**                      		787_GW_BPCU_SWDD-20868
**                      		787_GW_BPCU_SWDD-20172
**                      		787_GW_BPCU_SWDD-20171
**                      		787_GW_BPCU_SWDD-20177
**                      		787_GW_BPCU_SWDD-20178
**                      		787_GW_BPCU_SWDD-20179
**                         		787_GW_BPCU_SWDD-20870
**                         		787_GW_BPCU_SWDD-20176
**                         		787_GW_BPCU_SWDD-20198
**                         		787_GW_BPCU_SWDD-20601   
**                         		787_GW_BPCU_SWDD-20602  
**                         		787_GW_BPCU_SWDD-20180 
**                         		
**
*****************************************************************************
**
** Units Tested: ssx_healthmonitor.c
**
******************************************************************************
**
** Assumptions and Constraints : 
**   None
*****************************************************************************
**
** Criteria for Evaluating Results:
**   All data listed under Expected Outputs must exactly match the listed
**   result or range expressed.
**
*****************************************************************************/


#include "VesaModuleTestExecutive.h"
#include "Verify_Output.h"

#ifndef GW_APP_SSX_HEALTHMONITOR_PER_FUNC_H
#define GW_APP_SSX_HEALTHMONITOR_PER_FUNC_H


TESTSTATUS GW_APP_ssx_healthmonitor_Per_Func(void);


#endif
