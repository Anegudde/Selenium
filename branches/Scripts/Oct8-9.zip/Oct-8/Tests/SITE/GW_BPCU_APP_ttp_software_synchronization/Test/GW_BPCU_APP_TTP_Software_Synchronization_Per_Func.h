/********************************************************************************
**
**                                  WARNING
**
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
*******************************************************************************
**
**
**     Test Identification: GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.h
**
**     This file's version information ::
**     $RCSfile: GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.h $
**     $Revision: 1.1 $
**
** Software Configuration Index (SCI): DS10596/224
**
** Software Level: A
**
*******************************************************************************
**
**      Author(s): Anushree.MS
**
*******************************************************************************
**                            History
**
**        Date        Initials   Description
**
**        30-Sep-12     AMS       Initial version
******************************************************************************
**
**     Test Support Environment: DS10596/225
**
*****************************************************************************
**
**Requirements Tested: SWRD:BPCU_SWRD-22652
**                          BPCU_SWRD-22660
**                          BPCU_SWRD-22661
**                          BPCU_SWRD-22663
**                          BPCU_SWRD-22665 
**                          BPCU_SWRD-22668
**                          BPCU_SWRD-22669
**                          BPCU_SWRD-22671
**                          BPCU_SWRD-22674 
**                          BPCU_SWRD-36747 
**                          BPCU_SWRD-36748
**                          BPCU_SWRD-36749
**                          BPCU_SWRD-36751
**
**                      SWDD:787_GW_BPCU_SWDD-13743
**                           787_GW_BPCU_SWDD-13744
**                           787_GW_BPCU_SWDD-13745
**                           787_GW_BPCU_SWDD-13749
**                           787_GW_BPCU_SWDD-13750
**                           787_GW_BPCU_SWDD-13757
**                           787_GW_BPCU_SWDD-13758
**                           787_GW_BPCU_SWDD-13759
**                           787_GW_BPCU_SWDD-13760
**                           787_GW_BPCU_SWDD-13761
**                           787_GW_BPCU_SWDD-13762
**                           787_GW_BPCU_SWDD-16574
**                           787_GW_BPCU_SWDD-16575
**                           787_GW_BPCU_SWDD-14478
*****************************************************************************
**
** Units Tested: TTP_Software_Synchronization.c
**
******************************************************************************
**
** Assumptions and Constraints : 
**
**   Gateway BPCU SWDD traced to SWRD has been referred 
**   to realize the test cases of this test script.
******************************************************************************
**
**     Criteria for Evaluating Results:
**
**     All data listed under Expected Outputs must exactly match
**     the listed result or range expressed.
**
*******************************************************************************
*/

#include "VesaModuleTestExecutive.h"
#include "Verify_Output.h"

#ifndef GW_BPCU_APP_TTP_SOFTWARE_SYNCHRONIZATION_PER_FUNC_H
#define GW_BPCU_APP_TTP_SOFTWARE_SYNCHRONIZATION_PER_FUNC_H

TESTSTATUS GW_BPCU_APP_TTP_Software_Synchronization_Per_Func(void);

#endif

/********END of GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.h*************/
