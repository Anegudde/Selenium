/****************************************************************************
**
**                                 WARNING
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
****************************************************************************
**
** Test Identification: "GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.c"
**
**     This file's version information ::
**     $RCSfile: GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.c $
**     $Revision: 1.4 $
**
** Software Configuration Index (SCI): DS10596/224
**
** Software Level: A
**
*****************************************************************************
**
** Author(s): Anushree.MS /Raghavendra Keshavamurthy
**
******************************************************************************
**
**                                 History
**
**        Date        Initials   Description
**
**        01-Oct-12      AMS     Initial version
**        08-Dec-12      KM      Updated the script to Run on Target.
**        21-AUG-13      DKR     Updated the script for CR5011.
******************************************************************************
**
** Test Support Environment: DS10596/225
**
*****************************************************************************
**
**Requirements Tested: SWRD:BPCU_SWRD-22652
**                          BPCU_SWRD-22660
**                          BPCU_SWRD-22661
**                          BPCU_SWRD-22663
**                          BPCU_SWRD-22665 
**                          BPCU_SWRD-22668
**                          BPCU_SWRD-22669
**                          BPCU_SWRD-22671
**                          BPCU_SWRD-22674 
**                          BPCU_SWRD-36747 
**                          BPCU_SWRD-36748
**                          BPCU_SWRD-36749
**                          BPCU_SWRD-36751
**
**                      SWDD:787_GW_BPCU_SWDD-13743
**                           787_GW_BPCU_SWDD-13744
**                           787_GW_BPCU_SWDD-13745
**                           787_GW_BPCU_SWDD-13749
**                           787_GW_BPCU_SWDD-13750
**                           787_GW_BPCU_SWDD-13757
**                           787_GW_BPCU_SWDD-13758
**                           787_GW_BPCU_SWDD-13759
**                           787_GW_BPCU_SWDD-13760
**                           787_GW_BPCU_SWDD-13761
**                           787_GW_BPCU_SWDD-13762
**                           787_GW_BPCU_SWDD-16574
**                           787_GW_BPCU_SWDD-16575
**                           787_GW_BPCU_SWDD-14478
**                           787_GW_BPCU_SWDD-21151
**                           787_GW_BPCU_SWDD-16575
**                           787_GW_BPCU_SWDD-21152
**
*****************************************************************************
**
** Units Tested: TTP_Software_Synchronization.c
**
******************************************************************************
**
**     Assumptions and Constraints:
**
**   Gateway BPCU SWDD traced to SWRD has been referred 
**   to realize the test cases of this test script.
*****************************************************************************
**
** Criteria for Evaluating Results:
**   All data listed under Expected Outputs must exactly match the listed
**   result or range expressed.
**
*****************************************************************************/

#include "OS/OS_APIs.h"
#include "SS/SS_APIs.h"
#include "App_Get_DEC.h"
#include "App_Set_DEC.h"
#include "ttp_initialization.h"
#include "ttp_network_preference.h"
#include "GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.h"
#include "SS_INTR_DISABLE.H"
#include "SS_INTR_ENABLE.H"


/*Variable stubbing starts here*/
typedef struct
{
    tt_ttp_Protocol_State	ppdn1_protocol_state;
    tt_ttp_Protocol_State	ppdn2_protocol_state;
    ubyte1					primary_ttp_network;
    ubyte1					cluster_round_num;
    ubyte2					cluster_slot_num;
    ubyte1					round_slot_num;
    SS_U32					decr_time;
    ubyte2					sw_sync_shift;
    ubyte1					sw_sync_state;
    ubyte2					sw_sync_run_counter;
    ubyte2					sw_out_sync_counter;

} test_sw_sync;

extern test_sw_sync sw_sync;
ubyte1 Round_Number_25ms;


SS_U32 LruID;

SS_U32 Counter_5ms_Tasks;

struct _tt_tdc_FCL_Contr_Frame_Config v1_tdc_FCL_Contr_Frame_Config;
struct _tt_tdc_FCL_Contr_Frame_Config v2_tdc_FCL_Contr_Frame_Config;

const tt_LRU_Descriptor LRU_Config [] =
{
    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}}


}; /*End of variable stubbing*/

/* Global Test Variables */
tt_ttp_Protocol_State	ppdn1_protocol_state;
tt_ttp_Protocol_State	ppdn2_protocol_state;

tt_ttp_C_State ppdn_c_state;
ubyte1 SWITCH_SLOT;

ubyte1 Primary_TTP_Network;

ubyte2 sw_sync_shift;
ubyte2 round_slot;
ubyte2 ppdn_global_time;
ubyte2 ppdn_round_slot_time;


unsigned int decr_time;
extern ubyte1 SW_Sync_State;

extern BOOL tt_ttp_get_c_state_Invoked;
extern BOOL tt_ttp_get_global_time_Invoked;
extern BOOL SS_INTR_Disable_Invoked;
extern SS_INTR_DISABLE_MASK SS_INTR_Disable_DisableMSR;
extern BOOL SS_INTR_Enable_Invoked;
extern SS_INTR_ENABLE_MASK SS_INTR_Enable_EnableMSR;


extern  CSA_U32 Test_Flag;
extern  CSA_U32 Test_Flag1;
extern  CSA_U32 Test_Call;

	
#define OUT_SYNC	2
#define IN_SYNC		1

TESTSTATUS GW_BPCU_APP_TTP_Software_Synchronization_Per_Func(void)
{

    /* For switching into the different test cases */
    static short   TestCase ;

    /* To hold the Test status */
    TESTSTATUS     Status = IN_PROGRESS;

    /* To hold and print the test case results */
    VER_BOOLEAN    TestCaseResult;

    unsigned int Failcount, Exp_Test_flag;

    switch (TestCase)
    {
        case 0:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 1                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13743                      ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                "); 
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that SW_Sync_State is set to UNKNOWN and                   ");
            Print_Test_Header("**        The functions tt_ttp_get_c_state,tt_ttp_get_global_time,             ");    
            Print_Test_Header("**        SS_INTR_Disable and SS_INTR_Enable functions are                     ");
            Print_Test_Header("**        not called , when                                                    ");
            Print_Test_Header("**        1.ppdn1_protocol_state is not Equal to TT_TTP_ACTIVE                 ");
            Print_Test_Header("**        2.ppdn2_protocol_state=TT_TTP_ACTIVE                                 ");
            Print_Test_Header("**        3.Primary_TTP_Network=PPDN1                                          ");
            Print_Test_Header("****************************************************************************/  ");


            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;

			  Primary_TTP_Network=PPDN1;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
              SW_Sync_State=PPDN1;
			  LruID=1;

            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");



            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_FALSE)&&(tt_ttp_get_global_time_Invoked==CSA_FALSE)&&
			    (SW_Sync_State==UNKNOWN)&& (SS_INTR_Disable_Invoked==CSA_FALSE) && (SS_INTR_Enable_Invoked==CSA_FALSE))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerifying that the function tt_ttp_get_c_state() is not invoked ");	
            Print_Test_Header("\nVerifying that the function tt_ttp_get_global_time() is not invoked ");	
            Print_Test_Header("\nVerification for SW_Sync_State.");		
			
            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);


			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 0 */


        case 1:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 2                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                "); 
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that SW_Sync_State is set to UNKNOWN and                   ");
            Print_Test_Header("**        The functions tt_ttp_get_c_state,tt_ttp_get_global_time,             ");    
            Print_Test_Header("**        SS_INTR_Disable and SS_INTR_Enable functions are                     ");
            Print_Test_Header("**        not called , when                                                    ");
            Print_Test_Header("**        1.ppdn1_protocol_state is equal to TT_TTP_ACTIVE                     ");
            Print_Test_Header("**        2.ppdn2_protocol_state is not equal to TT_TTP_ACTIVE                 ");
            Print_Test_Header("**        3.Primary_TTP_Network is equal to PPDN2                              ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=1;

			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SW_Sync_State=PPDN1;
			   LruID=1;

            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");



            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_FALSE)&&(tt_ttp_get_global_time_Invoked==CSA_FALSE)&&
			    (SW_Sync_State == UNKNOWN)&& (SS_INTR_Disable_Invoked==CSA_FALSE) && (SS_INTR_Enable_Invoked==CSA_FALSE))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerifying that the function tt_ttp_get_c_state() is not invoked ");	
            Print_Test_Header("\nVerifying that the function tt_ttp_get_global_time() is not invoked ");		
            Print_Test_Header("\nVerification for SW_Sync_State.");					

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 1 */
		  
		  
		  
        case 2:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 3                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22671                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36751                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13749                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13750                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13759                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2.The TDMA round number is aligned with the 25ms task, and the  "); 
            Print_Test_Header("**               current round slot number is allocated to the configured unit.");     
            Print_Test_Header("**             3.When the SW Sync Shift is outside the SW Sync Window and      ");
            Print_Test_Header("**               greater than zero, the decrementer register value is decreased");
            Print_Test_Header("**               by 50 micro seconds                                           ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("** Note:To verify that                                                         ");
            Print_Test_Header("**      1.SW_Sync_State is set to OUT_SYNC and the functions                   "); 
            Print_Test_Header("**        tt_ttp_get_c_state,tt_ttp_get_global_time,                           ");
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:                 "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**       2.delta1 = ppdn_global_time - ppdn_c_state.time when                  ");
            Print_Test_Header("**          1. round_slot_num is equal to SWITCH_SLOT,                         ");
            Print_Test_Header("**          2. The ppdn_global_time greater than ppdn_c_state.time .           ");
            Print_Test_Header("**       3. SW_Sync_State = OUT_SYNC                                           ");
            Print_Test_Header("**          decr_time = decr_time - SW_SYNC_ADJ ,when SW Sync Shift is not     ");
            Print_Test_Header("**          SW_SYNC_ZONE                                                       ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=1;
			  Test_Call=0;
			  Primary_TTP_Network=PPDN2;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;


               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;
              
              


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 2 */


		  
        case 3:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 4                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");;
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13749                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13750                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2.The TDMA round number is aligned with the 25ms task, and the  "); 
            Print_Test_Header("**               current round slot number is allocated to the configured unit.");     
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("** Note:To verify that                                                         ");
            Print_Test_Header("**      1.SW_Sync_State is set to OUT_SYNC and the functions                   "); 
            Print_Test_Header("**        tt_ttp_get_c_state,tt_ttp_get_global_time,                           ");
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:                 "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**       2.delta1 = TOTAL_TIMER_COUNT +  ppdn_global_time - ppdn_c_state.time  ");
            Print_Test_Header("**         when                                                                ");
            Print_Test_Header("**          1. round_slot_num is equal to SWITCH_SLOT,                         ");
            Print_Test_Header("**          2. The ppdn_global_time is not greater than ppdn_c_state.time .    ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=6;
			  Test_Call=1;
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;

               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
               
               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 3 */		  
		  
			
        case 4:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 5                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13745                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**      1.SW_Sync_State is set to unknown  and the functions                   "); 
            Print_Test_Header("**        tt_ttp_get_c_state,tt_ttp_get_global_time,                           ");
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:                 "); 
            Print_Test_Header("**        1.ppdn1_protocol_state is not Equal to TT_TTP_ACTIVE                 ");
            Print_Test_Header("**        2.ppdn2_protocol_state is not Equal toTT_TTP_ACTIVE                  ");
            Print_Test_Header("**        3.Primary_TTP_Network=PPDN1                                          ");
            Print_Test_Header("****************************************************************************/  ");


            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=2;

			  Primary_TTP_Network=PPDN1;

            /* Setting other than expected value */
               SW_Sync_State=PPDN1;
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
			   LruID=1;
               

            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");



            /* Expected and Actual values comparison */

            if ((SW_Sync_State==UNKNOWN)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* Printing Variable under test */

            Print_Test_Header("\nVerification for SW_Sync_State.");

            /* print the expected and actual values in the result file */

            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 4 */	

        case 5:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 6                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22661                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13762                      ");
             Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
           Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");              
            Print_Test_Header("**            1.The Software synchronization is  occured                       ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is in       ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**            2.When current round slot number is less than configured slot    "); 
            Print_Test_Header("**              number, decrementer register value is increased by 50          "); 
            Print_Test_Header("**              micro seconds.                                                 ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       ");
            Print_Test_Header("**      1.SW_Sync_State is set to OUT_SYNC and the functions                   "); 
            Print_Test_Header("**        tt_ttp_get_c_state,tt_ttp_get_global_time,                           ");
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:                 "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2 and                              ");
            Print_Test_Header("**       2.decr_time = decr_time + SW_SYNC_ADJ when round_slot_num is not      ");
            Print_Test_Header("**         equal(less than) to SWITCH_SLOT                                     ");                                  
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=3;
              Test_Call=0;			  
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
              SW_Sync_State=PPDN1;
			   SWITCH_SLOT=3;
			   Counter_5ms_Tasks=1;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);	

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 5 */	
		  
		  
		  

        case 6:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 7                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22660                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13761                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");              
            Print_Test_Header("**            1.The Software synchronization is  occured                       ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is in       ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**            2.When current round slot number is greater  than configured     "); 
            Print_Test_Header("**              slot number, decrementer register value is decreased by 50     "); 
            Print_Test_Header("**              micro seconds.                                                 ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       ");
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2 and                              ");
            Print_Test_Header("**       2.SW_Sync_State is set to OUT_SYNC,decr_time = decr_time - SW_SYNC_ADJ");
            Print_Test_Header("**         when round_slot_num is greater than to SWITCH_SLOT                  ");      
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=3;
              Test_Call=0;			  
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
			   LruID=1;
               
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);				

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 6 */	
		  
		  
        case 7:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 8                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13743                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is  occured         ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is in       ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**   Note:To verify that                                                       ");
            Print_Test_Header("**           1.Primary_TTP_Network equals PPDN1 and                            ");
            Print_Test_Header("**             PPDN1_Protocol_State equals TT_TTP_ACTIVE then                  ");
            Print_Test_Header("**             The tt_ttp_get_c_state function is called and PPDN1 network c   "); 
            Print_Test_Header("**             state is assigned to ppdn_c_state. The tt_ttp_get_global_time   "); 
            Print_Test_Header("**             function is called and PPDN1 network global time is assigned    ");
            Print_Test_Header("**             to ppdn_global_time.                                            ");
            Print_Test_Header("**           2.SW_Sync_State set to  OUT_SYNC                                  ");
            Print_Test_Header("**           3.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,        ");
            Print_Test_Header("**             SS_INTR_DISABLE and SS_INTR_ENABLE are called.                   "); 
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=1;
              Test_Call=0;
			  Primary_TTP_Network=PPDN1;
			  LruID=1;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SW_Sync_State=PPDN1;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			     (SW_Sync_State==OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");	
            Print_Test_Header("\nVerification for SW_Sync_State.");	
			
            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);
			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 7 */			  

        case 8:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 9                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36747                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36748                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36749                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16574                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2. The 25 ms task is aligned with TDMA round numbers            ");
            Print_Test_Header("**             3. When TDMA round number is not aligned, decrementer register  "); 
            Print_Test_Header("**               value be adjusted by 50 micro seconds to align 25 ms task to  ");
            Print_Test_Header("**               nearest TDMA round number                                     ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**       2.SW_Sync_State = OUT_SYNC when Task_25ms_5_Round_Counter not equal   ");  
            Print_Test_Header("**         to TDMA_5_Round_Counter                                             ");
            Print_Test_Header("**       3.decr_time = decr_time + SW_SYNC_ADJ when                            ");
            Print_Test_Header("**        SHIFT_DIRECTION [Task_25ms_5_Round_Counter][TDMA_5_Round_Counter]    ");
            Print_Test_Header("**        equal to RIGHT                                                       ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=2;
              Test_Call=0;			  
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=2;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 8 */	
		  


        case 9:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 10                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36747                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36748                             ");
            Print_Test_Header("**                                 BPCU_SWRD-36749                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16574                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2. The 25 ms task is aligned with TDMA round numbers            ");
            Print_Test_Header("**             3. When TDMA round number is not aligned, decrementer register  "); 
            Print_Test_Header("**               value be adjusted by 50 micro seconds to align 25 ms task to  ");
            Print_Test_Header("**               nearest TDMA round number                                     ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**       2.SW_Sync_State = OUT_SYNC when Task_25ms_5_Round_Counter not equal   ");  
            Print_Test_Header("**         to TDMA_5_Round_Counter                                             ");
            Print_Test_Header("**       3.decr_time = decr_time - SW_SYNC_ADJ when                            ");
            Print_Test_Header("**        SHIFT_DIRECTION [Task_25ms_5_Round_Counter][TDMA_5_Round_Counter]    ");
            Print_Test_Header("**        not equal to RIGHT .                                                 ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=5;
              Test_Call=0;			  
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=2;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);
		 
			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 9 */	

        case 10:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 11                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22663                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22665                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22669                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13758                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**               SW Sync Shift be calculated in the following manner           ");
            Print_Test_Header("**             2.Delta1 = Current global time - Start time of current slot.    ");
            Print_Test_Header("**               Delta2 = Initial decrementer setting - Current decrementer    ");
            Print_Test_Header("**               register value SW Sync Shift = Delta1 - Delta2and             ");
            Print_Test_Header("**             3.When SW Sync Shift is within SW Sync Window and less than     "); 
            Print_Test_Header("**               SW Sync Window center, decrementer register value is increased");
            Print_Test_Header("**               by the difference between the SW Sync Window center and       ");
            Print_Test_Header("**               SW Sync Shift plus 1 micro second.                            ");     
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**        2.SW_Sync_State = IN_SYNC and sw_sync_tune =                         ");
            Print_Test_Header("**         (SW_SYNC_CENTER - sw_sync_shift + 1) / 2,                           ");
            Print_Test_Header("**         decr_time = decr_time + sw_sync_tune. when sw_sync_shift less than  ");   
            Print_Test_Header("**         SW_SYNC_ZONE and sw_sync_shift is not greater than SW_SYNC_CENTER   ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=7;
			  Test_Call=1;
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;


               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == IN_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (IN_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);
	  
			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 10 */	
		  
        case 11:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 12                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22663                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22665                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22668                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13757                      ");
            Print_Test_Header("**                                787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**               SW Sync Shift be calculated in the following manner           ");
            Print_Test_Header("**             2.Delta1 = Current global time - Start time of current slot.    ");
            Print_Test_Header("**               Delta2 = Initial decrementer setting - Current decrementer    ");
            Print_Test_Header("**               register value SW Sync Shift = Delta1 - Delta2and             ");
            Print_Test_Header("**             3.When SW Sync Shift is within SW Sync Window and greater than  "); 
            Print_Test_Header("**               SW Sync Window center, decrementer register value is decreased");
            Print_Test_Header("**               by the difference between the SW Sync Shift and SW Sync Window");
            Print_Test_Header("**               center plus 1 micro second.                                   ");     
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**        2.SW_Sync_State = IN_SYNC and sw_sync_tune =                         ");
            Print_Test_Header("**         (sw_sync_shift - SW_SYNC_CENTER + 1) / 2,                           ");
            Print_Test_Header("**         decr_time = decr_time - sw_sync_tune. when sw_sync_shift less than  ");   
            Print_Test_Header("**         SW_SYNC_ZONE and sw_sync_shift is greater than SW_SYNC_CENTER       ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=8;
			  Test_Call=1;
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;


               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
			   LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == IN_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (IN_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 11 */	

        case 12:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 13                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22652                             ");                         
            Print_Test_Header("**                                 BPCU_SWRD-22674                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-13744                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-13760                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21151                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-16575                      ");
            Print_Test_Header("**                                 787_GW_BPCU_SWDD-21152                      ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");  
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");    
            Print_Test_Header("**             2.When the SW Sync Shift is outside the SW Sync Window and less "); 
            Print_Test_Header("**               than zero, the decrementer register value increased           ");
            Print_Test_Header("**               by 50 micro seconds.                                          ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**          SS_INTR_DISABLE and SS_INTR_ENABLE are called, when:               "); 
            Print_Test_Header("**         1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                   ");
            Print_Test_Header("**         2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                       ");
            Print_Test_Header("**         3.Primary_TTP_Network equal PPDN2 and the                           ");
            Print_Test_Header("**        2.SW_Sync_State = OUT_SYNC and decr_time = decr_time + SW_SYNC_ADJ   ");
            Print_Test_Header("**          when If delta1 is not greater than delta2                          ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=9;
			  Test_Call=1;
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;			
               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   Counter_5ms_Tasks=1;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
			   LruID=1;
			   
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 12 */	

        case 13:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 14                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:None                                        ");                         
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                            SWDD:787_GW_BPCU_SWDD-14478                      ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that SW_Sync_State is set to UNKNOWN                  ");
            Print_Test_Header("**                                                                             ");  
            Print_Test_Header("**                                                                             ");                                                 
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Setting other than expected value */
               SW_Sync_State=PPDN1;
			   LruID=1;
			   
            /* Function under test Invocation */
            TTP_Software_Synchronization_Init();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("GW_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
;		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if (SW_Sync_State == UNKNOWN)
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			
            /* While test is completed the variable is set to COMPLETED */
            Status = COMPLETED;

											
            break;
        }/* end of Case 13 */

    }/*End of Switch case */

/*Return the Status */
return Status;

}

/********END of GW_BPCU_APP_TTP_Software_Synchronization_Per_Func.C*************/


