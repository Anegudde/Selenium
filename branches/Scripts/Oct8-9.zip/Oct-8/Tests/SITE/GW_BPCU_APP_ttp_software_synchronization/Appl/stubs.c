

#include "tt_ttp_defines.h"
#include "tt_ttp_il_defines.h"
#include "tt_ttp_hal_def.h"
#include "OS/OS_APIs.h"
#include "SS/SS_APIs.h"
#include "App_Get_DEC.h"
#include "App_Set_DEC.h"
#include "ttp_initialization.h"
#include "ttp_network_preference.h"
#include "ttp_software_synchronization.h"
#include "SS/SS_Types.h"
#include "SS/SS_Defs.h"
#include "SS_INTR_DISABLE.H"
#include "SS_INTR_ENABLE.H"



typedef struct
{
    unsigned short	ppdn1_protocol_state;
    unsigned short	ppdn2_protocol_state;
    unsigned char	primary_ttp_network;
    unsigned char	cluster_round_num;
    unsigned short	cluster_slot_num;
    unsigned char	round_slot_num;
    unsigned int decr_time;
    unsigned short	sw_sync_shift;
    unsigned char	sw_sync_state;
    unsigned short	sw_sync_run_counter;
    unsigned short	sw_out_sync_counter;

} test_sw_sync;

extern unsigned char PPDN1Active;
extern unsigned char PPDN2Active; 

extern tt_ttp_Protocol_State PPDN1_Protocol_State;
extern tt_ttp_Protocol_State PPDN2_Protocol_State;
test_sw_sync sw_sync;
extern ubyte2 ppdn_global_time;
extern ubyte2 ppdn_round_slot_time;
extern ubyte2 round_slot;
extern unsigned int decr_time;

unsigned int i;

/*from stub*/
BOOL tt_ttp_get_c_state_Invoked;
BOOL tt_ttp_get_global_time_Invoked;
BOOL SS_INTR_Disable_Invoked;
SS_INTR_DISABLE_MASK SS_INTR_Disable_DisableMSR;
BOOL SS_INTR_Enable_Invoked;
SS_INTR_ENABLE_MASK SS_INTR_Enable_EnableMSR;


CSA_U32 Test_Flag;
CSA_U32 Test_Flag1;
CSA_U32 Test_Call;

OS_U32 App_Get_DEC(void)
{
  return 800;
}

void App_Set_DEC(unsigned int decValue)
{
  /*decr_time is used for the delta2 calculation, do not alter it again.*/
  decr_time = decValue;
  return;
}

void tt_ttp_get_protocol_state ( tt_Controller_Base controller
                               , tt_ttp_Protocol_State *state
                               )
{   
    /* set protocol state to inactive according if value in test file*/
    if (Test_Flag == 0)
    {
        /* TT_TTP_FREEZE = 0X0
        , TT_TTP_INIT = 0X1
        , TT_TTP_LISTEN = 0X2
        , TT_TTP_COLDSTART = 0X3
        , TT_TTP_ACTIVE = 0X4
        , TT_TTP_PASSIVE = 0X5
        , TT_TTP_AWAIT = 0X6
        , TT_TTP_DOWNLOAD = 0X8
        , TT_TTP_DOWNLOAD_MASTER = 0XF */

                           
        *state = (tt_ttp_Protocol_State)TT_TTP_PASSIVE;
		
		Test_Flag++;
     }
	 
	 else if(Test_Flag == 1)
	 {
	 *state = (tt_ttp_Protocol_State)TT_TTP_ACTIVE;
	 
	 Test_Flag++;
	 }
	 
    else if(Test_Flag == 2)		 
    {
         /* TT_TTP_FREEZE = 0X0
        , TT_TTP_INIT = 0X1
        , TT_TTP_LISTEN = 0X2
        , TT_TTP_COLDSTART = 0X3
        , TT_TTP_ACTIVE = 0X4
        , TT_TTP_PASSIVE = 0X5
        , TT_TTP_AWAIT = 0X6
        , TT_TTP_DOWNLOAD = 0X8
        , TT_TTP_DOWNLOAD_MASTER = 0XF */
        *state = (tt_ttp_Protocol_State)TT_TTP_PASSIVE;
    }
}

tt_ttp_Ret_NN tt_ttp_get_c_state (tt_Controller_Base controller,
								       tt_ttp_C_State *c_state)
{
if (Test_Flag1==1)
{
    c_state->time=0;
	c_state->round_slot=80;
}

else if (Test_Flag1==2)
{
    c_state->time=0;
	c_state->round_slot=82;	
}

else if (Test_Flag1==3)
{
    c_state->time=0;
    c_state->round_slot=81;
}

else if (Test_Flag1==4)
{
    c_state->time=0;
    c_state->round_slot=81;
}

else if (Test_Flag1==5)
{
    c_state->time=0;
    c_state->round_slot=112;
}

else if (Test_Flag1==6)
{
    c_state->time=1;
    c_state->round_slot=80;
}

else if (Test_Flag1==7)
{
    c_state->time=64532;
	c_state->round_slot=80;	
}

else if (Test_Flag1==8)
{
    c_state->time=64512;
    c_state->round_slot=80;
}

else if (Test_Flag1==9)
{
    c_state->time=65536;
    c_state->round_slot=80;
}
   tt_ttp_get_c_state_Invoked=CSA_TRUE;

  return TT_TTP_ACTIVE;
}

void tt_ttp_get_global_time (tt_Controller_Base controller,
							      tt_ttp_Time *time)
{

    if (Test_Call == 0)
	{
   *time = (tt_ttp_Time)65532;
   
    }
else if (Test_Call == 1)
	{
   *time = (tt_ttp_Time)0;
   
    }
   tt_ttp_get_global_time_Invoked=CSA_TRUE;
}

void SS_INTR_Disable (SS_INTR_DISABLE_MASK  DisableMSR )
{
SS_INTR_Disable_Invoked = CSA_TRUE;
SS_INTR_Disable_DisableMSR = DisableMSR;

return;

}

void SS_INTR_Enable (SS_INTR_ENABLE_MASK  EnableMSR )
{

SS_INTR_Enable_Invoked = CSA_TRUE;
SS_INTR_Enable_EnableMSR = EnableMSR;

return;

}
