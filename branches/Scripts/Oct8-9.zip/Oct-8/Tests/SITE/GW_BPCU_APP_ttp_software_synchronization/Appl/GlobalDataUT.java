/*************************************************************************
WARNING
   Copyright 2010 Hamilton Sundstrand Corporation. This document is the
   property of Hamilton Sundstrand Corporation ("HSC"). You may not possess,
   use, copy or disclose this document or any information in it, for any
   purpose, including without limitation, to design, manufacture or repair
   parts, or obtain any government approval to do so, without HSC's express
   written permission. Neither receipt nor possession of this document
   alone, from any source, constitutes such permission. Possession, use,
   copying or disclosure by anyone without HSC's express written permission
   is not authorized and may result in criminal and/or civil liability.
  ***************************************************************************

                              *************************
                              *                       *
                              *   GlobalDataUT.java *
                              *                       *
                              *************************

unit title:  GlobalDataUT.java
@author(s):  Anushree.MS
****************************************************************************
description:

     This class will provide access to enums used for UT

     Description

     Requirements
     N/A,  This is an enumeration


partitioning information VESA Client
****************************************************************************
VERSION        : %full_filespec %
****************************************************************************/
package tIO_Unit_Test;

public class GlobalDataUT {

	// emuneration of the BOOLC data used
    public enum TEST_NAME
	  {
    	VER_NO_TEST,
    	GW_BPCU_APP_TTP_Software_Synchronization_Per_Func,
 	  }
	public TEST_NAME test;

	/**
	 * get Index - returns the index of enum value of flag
	 *
	 * @param none
	 *
	 * @return  ordinary of the flag (Index into the enumeration
	 */
	public int getIndex()
	{
		return(test.ordinal());
	}


}
