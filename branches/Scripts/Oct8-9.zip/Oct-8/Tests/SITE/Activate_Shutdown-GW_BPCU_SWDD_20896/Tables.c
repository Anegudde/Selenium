/*******************************************************************************
**
**                                  WARNING
**
**   Copyright Hamilton Sundstrand Corporation. This document is the property
**   of Hamilton Sundstrand Corporation ("HS"). You may not possess, use,
**   copy or disclose this document or any information in it, for any purpose,
**   including without limitation, to design, manufacture or repair parts,
**   or obtain any government approval to do so, without HS's express written
**   permission. Neither receipt nor possession of this document alone, from
**   any source, constitutes such permission. Possession, use, copying or
**   disclosure by anyone without HS's express written permission is
**   not authorized and may result in criminal and/or civil liability.
**
********************************************************************************
**
**          *****************************************************
**          *   Tables.c                                        *
**          *****************************************************
**
**
**   Test Identification:  Func Pointer file
**                         for Activate_Shutdown_Per_Func.c
**
**   Software Configuration Index (SCI): DS10596/224
**
********************************************************************************
**
**   Author(s): RAGHAVENDRA.DK
**
********************************************************************************
**                           History
**
**  Starteam:
**   $Log:
**    3    1112 - 787-9 ESS 1.2         8/14/2012 10:28:13 AM  Christopher D.
**         Schin Updated per AIs
**    2    1112 - 787-9 ESS 1.1         8/6/2012 2:46:42 PM    Jonathan R.
**         Grommes Updated
**    1    1112 - 787-9 ESS 1.0         7/30/2012 9:43:51 AM   Brian L. Trumpy
**         SITE MT RBTs developed by HS for CR4538
**   $
**   $NoKeywords$
**
**  MKS:
**    $Log: Tables.c $
**    Revision 1.1  2012/08/14 10:26:56  aaegddb
**    Initial revision
**
********************************************************************************
**
**   Test Support Environment: DS10386/515
**
********************************************************************************
**
**   Requirements Tested:
**      SWRD:None
**      SWDD:
**       REQ:GW_BPCU_SWDD-20896
********************************************************************************
**
**   Certification Level:   DO-178B  Level A
**
*******************************************************************************/


#include "Tables.h"
#include "Activate_Shutdown_Per_Func.h"

TESTSTATUS (*FunctionPtr[])(void) =
{
    Ver_NO_Test,
    Activate_Shutdown_Per_Func,
};


