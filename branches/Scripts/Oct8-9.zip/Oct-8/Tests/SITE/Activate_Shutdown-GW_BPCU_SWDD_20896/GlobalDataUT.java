/*******************************************************************************
**
**                                  WARNING
**
**   Copyright Hamilton Sundstrand Corporation. This document is the property
**   of Hamilton Sundstrand Corporation ("HS"). You may not possess, use,
**   copy or disclose this document or any information in it, for any purpose,
**   including without limitation, to design, manufacture or repair parts,
**   or obtain any government approval to do so, without HS's express written
**   permission. Neither receipt nor possession of this document alone, from
**   any source, constitutes such permission. Possession, use, copying or
**   disclosure by anyone without HS's express written permission is
**   not authorized and may result in criminal and/or civil liability.
**
********************************************************************************
**
**          *****************************************************
**          *   GlobaldataUT_Activate_Shutdown.java             *
**          *****************************************************
**
**
**   Test Identification: GlobaldataUT_Activate_Shutdown
**
**   Software Configuration Index (SCI): DS10596/224
**
********************************************************************************
**
**   Author(s): RAGHAVENDRA.DK
**
********************************************************************************
**                           History
**
**  Starteam:
**   $Log:
**    3    1112 - 787-9 ESS 1.2         8/14/2012 10:28:13 AM  Christopher D.
**         Schin Updated per AIs
**    2    1112 - 787-9 ESS 1.1         8/6/2012 2:46:42 PM    Jonathan R.
**         Grommes Updated
**    1    1112 - 787-9 ESS 1.0         8/3/2012 9:35:21 AM    Bradley A. Rako
**         Added
**   $
**   $NoKeywords$
**
**  MKS:
**    $Log: GlobalDataUT.java $
**    Revision 1.1  2012/12/19 21:20:04  aaeearn
**    Initial revision
**    Revision 1.1  2012/08/14 10:26:58  aaegddb
**    Initial revision
**
********************************************************************************
**
**   Test Support Environment: DS10386/515
**
********************************************************************************
**
**   Requirements Tested:
**      SWRD:None
**      SWDD:
**       REQ:GW_BPCU_SWDD-20896
********************************************************************************
**
**   Certification Level:   DO-178B  Level A
**
*******************************************************************************/

package tIO_Unit_Test;

public class GlobalDataUT {

	// emuneration of the BOOLC data used
    public enum TEST_NAME
	  {
    	VER_NO_TEST,
    	ACTIVATE_SHUTDOWN_PER_FUNC,
 	  }
	public TEST_NAME test;

	/**
	 * get Index - returns the index of enum value of flag
	 *
	 * @param none
	 *
	 * @return  ordinary of the flag (Index into the enumeration
	 */
	public int getIndex()
	{
		return(test.ordinal());
	}


}
