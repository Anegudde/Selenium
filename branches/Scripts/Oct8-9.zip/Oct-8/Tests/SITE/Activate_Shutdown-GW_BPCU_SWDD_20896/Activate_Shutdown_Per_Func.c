/*******************************************************************************
**
**                                  WARNING
**
**   Copyright Hamilton Sundstrand Corporation. This document is the property
**   of Hamilton Sundstrand Corporation ("HS"). You may not possess, use,
**   copy or disclose this document or any information in it, for any purpose,
**   including without limitation, to design, manufacture or repair parts,
**   or obtain any government approval to do so, without HS's express written
**   permission. Neither receipt nor possession of this document alone, from
**   any source, constitutes such permission. Possession, use, copying or
**   disclosure by anyone without HS's express written permission is
**   not authorized and may result in criminal and/or civil liability.
**
********************************************************************************
**
**          *****************************************************
**          *   Active_Shutdown_Per_Func.c                      *
**          *****************************************************
**
**
**   Test Identification: Per Func for GW_Active_Shutdown.java
**
**   Software Configuration Index (SCI): DS10596/224
**
********************************************************************************
**
**   Author(s): RAGHAVENDRA.DK
**
********************************************************************************
**                           History
**
**  Starteam:
**   $Log:
**    3    1112 - 787-9 ESS 1.2         8/14/2012 10:28:13 AM  Christopher D.
**         Schin Updated per AIs
**    2    1112 - 787-9 ESS 1.1         8/6/2012 2:46:42 PM    Jonathan R.
**         Grommes Updated
**    1    1112 - 787-9 ESS 1.0         7/30/2012 9:43:51 AM   Brian L. Trumpy
**         SITE MT RBTs developed by HS for CR4538
**   $
**   $NoKeywords$
**
**  MKS:
**    $Log: Activate_Shutdown_Per_Func.c $
**    Revision 1.2  2013/09/06 15:04:10  keshavr
**    CR5026: Implemented the BT_WD_Trigger when   Watchdog_Started is SS_FALSE and  SS_TRUE.
**    Revision 1.1  2012/08/14 10:26:44  aaegddb
**    Initial revision
**
********************************************************************************
**
**   Test Support Environment: DS10386/515
**
********************************************************************************
**
**   Requirements Tested:
**      SWRD:None
**      SWDD:
**       REQ:GW_BPCU_SWDD-20896
**
********************************************************************************
**
**   Certification Level:   DO-178B  Level A
**
*******************************************************************************
**
**     Assumptions and Constraints:
**     None
**
******************************************************************************
**
**     Criteria for Evaluating Results:
**         Refer the generated .res(result) file for PASS/FAIL status.
**
******************************************************************************/

/* Include files*/
#include "Activate_Shutdown_Per_Func.h"
#include "Activate_Shutdown.h"
#include "Verify_Output.h"
#include "VesaModuleTestExecutive.h"
#include "SS/SS_APIs.h"
#include "SS/SS_Types.h"
#include "SS/SS_FaultHandler.h"
#include "SS/SS_FaultHandlerExitTypes.h"
#include "BT_APIs.h"

unsigned int TestCall;

SS_U32  __EXT_RAM_TEST_START_1;
SS_U32  __EXT_RAM_TEST_START_2;
SS_U32  __EXT_RAM_TEST_START_3;
SS_U32  __EXT_RAM_TEST_START_4;
SS_U32  __EXT_RAM_TEST_START_5;

SS_U32  __EXT_RAM_TEST_END_1;
SS_U32  __EXT_RAM_TEST_END_2;
SS_U32  __EXT_RAM_TEST_END_3;
SS_U32  __EXT_RAM_TEST_END_4;
SS_U32  __EXT_RAM_TEST_END_5;

SS_BOOL Watchdog_Started;


SS_U32 Test_faultHandlerExitType;
SS_U32 Test_faultCode;
SS_FAULT_SNAPSHOT_DATA *Test_faultSnapshotData;

/**/
SS_FAULT_SNAPSHOT_DATA Test_faultSnapshotData_Test;
/**/
extern SS_U32  SS_FaultHandler_faultHandlerExitType;
extern SS_U32  SS_FaultHandler_faultCode;
extern SS_FAULT_SNAPSHOT_DATA *SS_FaultHandler_faultSnapshotData;
extern unsigned int INVOKED_SS_FaultHandler;

extern SS_BOOL BT_WD_Trigger_Invoked;

TESTSTATUS Activate_Shutdown_Per_Func(void)
{

   /*For switching into the different test cases */
   static short   TestCase;

   /*To print the test case number */
   TEST_CASE_LIST CurrentTestCase;

   /* To hold the Test status */
   TESTSTATUS     retStatus = IN_PROGRESS;

   /*To hold and print the test case results */
   VER_BOOLEAN    TestCaseResult;

   /* Variable to hold the number of test failures */
   static unsigned int Failcount;

   VER_BOOLEAN Func_Return ;


switch (TestCase)
{

case 0:
{

Print_Test_Header("/******************************************************");
Print_Test_Header("**   Test Case: 1                                      ");
Print_Test_Header("**                                                     ");
Print_Test_Header("**   Requirements under test: REQ:GW_BPCU_SWDD-20896   ");
Print_Test_Header("**                                GW_BPCU_SWDD-21208   ");
Print_Test_Header("                                                       ");
Print_Test_Header("**    Normal/robustness test: Normal                   ");
Print_Test_Header("**                                                     ");
Print_Test_Header("**    Objective:The following verifies that            ");
Print_Test_Header("**              Active_Shutdown  call                  ");
Print_Test_Header("**              SS_FaultHandler,BT_WD_Trigger when      ");
Print_Test_Header("**              Watchdog_Started is SS_FALSE and        ");
Print_Test_Header("**              Snapshot data holds the                ");
Print_Test_Header("**              intermediate value                     ");
Print_Test_Header("*******************************************************");


    /* Initialise the TestCaseResult to FALSE */
    TestCaseResult = FALSE;

    /* To print the test case number in the results */
    CurrentTestCase = TC1;

 /*****************************************************************
 **
 **  Test Inputs:
 **
 ******************************************************************/

   Test_faultHandlerExitType = 1;
   Test_faultCode = 200;
   /**/
   Test_faultSnapshotData = &Test_faultSnapshotData_Test;
   /**/
   Test_faultSnapshotData->SnapShotData1 = 300;
   Test_faultSnapshotData->SnapShotData2 = 400;
   Test_faultSnapshotData->SnapShotData3 = 500;
   Test_faultSnapshotData->SnapShotData4 = 600;
   
   /*Implemented as a part of CR5026 */
   Watchdog_Started = SS_FALSE;
   BT_WD_Trigger_Invoked == CSA_FALSE;
   
  /* Call the function under test */
  Activate_Shutdown(Test_faultHandlerExitType,Test_faultCode,
                   Test_faultSnapshotData);

 /*****************************************************************
 **
 **  Expected Outputs:
 **
 ******************************************************************/


Print_Test_Header("/********************************************************/");
Print_Test_Header("/* Expected Output */                                     ");
Print_Test_Header("/********************************************************/");

     if((INVOKED_SS_FaultHandler == TRUE)&&
        (SS_FaultHandler_faultHandlerExitType ==
         Test_faultHandlerExitType)&&
        (SS_FaultHandler_faultCode ==Test_faultCode) &&
        (SS_FaultHandler_faultSnapshotData ->SnapShotData1
         ==Test_faultSnapshotData->SnapShotData1) &&
        (SS_FaultHandler_faultSnapshotData ->SnapShotData2
         ==Test_faultSnapshotData->SnapShotData2) &&
        (SS_FaultHandler_faultSnapshotData ->SnapShotData3
         ==Test_faultSnapshotData->SnapShotData3) &&
        (SS_FaultHandler_faultSnapshotData ->SnapShotData4
         ==Test_faultSnapshotData->SnapShotData4) &&
        (BT_WD_Trigger_Invoked == CSA_TRUE))     
     {

      TestCaseResult = TRUE ;
     }
     else
     {
        Failcount++ ;
     }

 /* Send test file name to result buffer for results verification */
Print_Test_Filename("Activate_Shutdown_Per_Func.c");

 /* Send test case ID to the result buffer for results verification*/
Print_Test_Case_ID(CurrentTestCase);

Print_Test_Case_Values(TRUE, TRUE, 16, INVOKED_SS_FaultHandler,
                        TestCaseResult);

 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(TestCaseResult);

Print_Test_Case_Values(SS_FaultHandler_faultHandlerExitType, TRUE,
                        16, Test_faultHandlerExitType ,
                       ((SS_FaultHandler_faultHandlerExitType ==
                       Test_faultHandlerExitType)? TRUE : FALSE));

 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultHandlerExitType ==
                         Test_faultHandlerExitType) ? TRUE : FALSE));

Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData1,
                        TRUE, 16, Test_faultSnapshotData->SnapShotData1 ,
                      ((SS_FaultHandler_faultSnapshotData->SnapShotData1 ==
                      Test_faultSnapshotData->SnapShotData1) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData1 ==
                       Test_faultSnapshotData->SnapShotData1) ? TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData2, TRUE,
                        16, Test_faultSnapshotData->SnapShotData2 ,(
                       (SS_FaultHandler_faultSnapshotData->SnapShotData2 ==
                       Test_faultSnapshotData->SnapShotData2) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData2 ==
                        Test_faultSnapshotData->SnapShotData2) ? TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData3, TRUE,
                        16, Test_faultSnapshotData->SnapShotData3 ,(
                       (SS_FaultHandler_faultSnapshotData->SnapShotData3 ==
                       Test_faultSnapshotData->SnapShotData3) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData3
                        == Test_faultSnapshotData->SnapShotData3) ?
                        TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData4,
                        TRUE, 16, Test_faultSnapshotData->SnapShotData4 ,(
                       (SS_FaultHandler_faultSnapshotData->SnapShotData4 ==
                       Test_faultSnapshotData->SnapShotData4) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData4
                         == Test_faultSnapshotData->SnapShotData4)
                         ? TRUE : FALSE));
 
Print_Test_Case_Values(CSA_TRUE, TRUE, 16, BT_WD_Trigger_Invoked,
                        TestCaseResult);                        

 Print_Test_Case_Result(TestCaseResult);

 
 /* print results for the test case PASSED/FAILED */

  TestCase++;

/* Mark the test in progress. */
retStatus = IN_PROGRESS;

break;
   } /* end of case 1 */

case 1:
{

Print_Test_Header("/*********************************************************");
Print_Test_Header("**   Test Case: 2                                         ");
Print_Test_Header("**                                                        ");
Print_Test_Header("**   Requirements under test: REQ:GW_BPCU_SWDD-20896      ");
Print_Test_Header("**                                GW_BPCU_SWDD-21208      ");
Print_Test_Header("**                                                        ");
Print_Test_Header("                                                          ");
Print_Test_Header("**    Normal/robustness test: Normal                      ");
Print_Test_Header("**                                                        ");
Print_Test_Header("**    Objective:The following verifies that               ");
Print_Test_Header("**              Active_Shutdown  call                     ");
Print_Test_Header("**              SS_FaultHandler, and BT_WD_Trigger is not  ");
Print_Test_Header("**              invoked when Watchdog_Started is SS_TRUE   ");
Print_Test_Header("**             and Snapshot data holds the Minimum value  ");
Print_Test_Header("**             data holds the Minimum value                ");

   /* Initialise the TestCaseResult to FALSE */
   TestCaseResult = FALSE;

   /* To print the test case number in the results */
   CurrentTestCase = TC2;

/*****************************************************************
**
**  Test Inputs:
**
******************************************************************/

  Test_faultHandlerExitType = 1;
  Test_faultCode = 0;
  /**/
  Test_faultSnapshotData = &Test_faultSnapshotData_Test;
  /**/
  Test_faultSnapshotData->SnapShotData1 = 0;
  Test_faultSnapshotData->SnapShotData2 = 0;
  Test_faultSnapshotData->SnapShotData3 = 0;
  Test_faultSnapshotData->SnapShotData4 = 0;
  
     /*Implemented as a part of CR5026 */
   Watchdog_Started = SS_TRUE;
   BT_WD_Trigger_Invoked = CSA_FALSE;

 /* Call the function under test */
 Activate_Shutdown(Test_faultHandlerExitType,Test_faultCode,
                   Test_faultSnapshotData);

 /*****************************************************************
 **
 **  Expected Outputs:
 **
 ******************************************************************/


Print_Test_Header("/********************************************************/");
Print_Test_Header("/* Expected Output */                                     ");
Print_Test_Header("/********************************************************/");

     if((INVOKED_SS_FaultHandler == TRUE)&&
        (SS_FaultHandler_faultHandlerExitType ==
         Test_faultHandlerExitType)&&
   (SS_FaultHandler_faultCode ==Test_faultCode) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData1 ==
   Test_faultSnapshotData->SnapShotData1) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData2 ==
   Test_faultSnapshotData->SnapShotData2) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData3 ==
   Test_faultSnapshotData->SnapShotData3) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData4 ==
   Test_faultSnapshotData->SnapShotData4) &&
        (BT_WD_Trigger_Invoked == CSA_FALSE))     
{

 TestCaseResult = TRUE ;
}
else
{
   Failcount++ ;
}

 /* Send test file name to result buffer for results verification */
Print_Test_Filename("Activate_Shutdown_Per_Func.c");

 /* Send test case ID to the result buffer for results verification */
Print_Test_Case_ID(CurrentTestCase);

Print_Test_Case_Values(TRUE, TRUE, 16, INVOKED_SS_FaultHandler, TestCaseResult);

 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(TestCaseResult);

Print_Test_Case_Values(SS_FaultHandler_faultHandlerExitType, TRUE,
                        16, Test_faultHandlerExitType ,
                       ((SS_FaultHandler_faultHandlerExitType ==
                       Test_faultHandlerExitType)? TRUE : FALSE));

 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultHandlerExitType ==
                         Test_faultHandlerExitType) ? TRUE : FALSE));


 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData1, TRUE,
                        16, Test_faultSnapshotData->SnapShotData1 ,(
                       (SS_FaultHandler_faultSnapshotData->SnapShotData1 ==
                       Test_faultSnapshotData->SnapShotData1) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData1
                        == Test_faultSnapshotData->SnapShotData1)
                        ? TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData2, TRUE,
                        16, Test_faultSnapshotData->SnapShotData2 ,(
                       (SS_FaultHandler_faultSnapshotData->SnapShotData2 ==
                       Test_faultSnapshotData->SnapShotData2) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData2
                        == Test_faultSnapshotData->SnapShotData2)
                        ? TRUE : FALSE));


 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData3, TRUE,
                        16, Test_faultSnapshotData->SnapShotData3 ,(
                        (SS_FaultHandler_faultSnapshotData->SnapShotData3
                     == Test_faultSnapshotData->SnapShotData3) ? TRUE : FALSE));

 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData3
 == Test_faultSnapshotData->SnapShotData3) ? TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData4, TRUE,
                        16, Test_faultSnapshotData->SnapShotData4 ,(
                        (SS_FaultHandler_faultSnapshotData->SnapShotData4 ==
                        Test_faultSnapshotData->SnapShotData4) ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData4
                     == Test_faultSnapshotData->SnapShotData4) ? TRUE : FALSE));
                     
Print_Test_Case_Values(CSA_FALSE, TRUE, 16, BT_WD_Trigger_Invoked,
                        TestCaseResult);                        

 Print_Test_Case_Result(TestCaseResult);
                     

TestCase++;

/* Mark the test in progress. */
retStatus = IN_PROGRESS;

break;

} /* end of case 2 */

case 2:
{

Print_Test_Header("/*********************************************************");
Print_Test_Header("**   Test Case: 3                                         ");
Print_Test_Header("**                                                        ");
Print_Test_Header("**   Requirements under test: REQ:GW_BPCU_SWDD-20896      ");
Print_Test_Header("**                                                        ");
Print_Test_Header("                                                          ");
Print_Test_Header("**    Normal/robustness test: Normal                      ");
Print_Test_Header("**                                                        ");
Print_Test_Header("**   Objective:The following verifies that Active_Shutdown");
Print_Test_Header("**             Shall call the SS_FaultHandler and Snapshot");
Print_Test_Header("**             data holds the Maximum value               ");
Print_Test_Header("**********************************************************");

/* Initialise the TestCaseResult to FALSE */
TestCaseResult = FALSE;

/* To print the test case number in the results */
CurrentTestCase = TC3;

/*****************************************************************
**
**  Test Inputs:
**
******************************************************************/


Test_faultHandlerExitType = 1;
Test_faultCode = 4294967295;
/**/
Test_faultSnapshotData = &Test_faultSnapshotData_Test;
/**/
Test_faultSnapshotData->SnapShotData1 = 4294967295;
Test_faultSnapshotData->SnapShotData2 = 4294967295;
Test_faultSnapshotData->SnapShotData3 = 4294967295;
Test_faultSnapshotData->SnapShotData4 = 4294967295;
 /* Call the function under test */
 Activate_Shutdown(Test_faultHandlerExitType,Test_faultCode,
                   Test_faultSnapshotData);

 /*****************************************************************
 **
 **  Expected Outputs:
 **
 ******************************************************************/
Print_Test_Header("/********************************************************/");
Print_Test_Header("/* Expected Output */                                     ");
Print_Test_Header("/********************************************************/");

     if((INVOKED_SS_FaultHandler == TRUE)&&
        (SS_FaultHandler_faultHandlerExitType ==
         Test_faultHandlerExitType)&&
   (SS_FaultHandler_faultCode ==Test_faultCode) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData1 ==
   Test_faultSnapshotData->SnapShotData1) &&
    (SS_FaultHandler_faultSnapshotData ->SnapShotData2 ==
      Test_faultSnapshotData->SnapShotData2) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData3
    ==Test_faultSnapshotData->SnapShotData3) &&
   (SS_FaultHandler_faultSnapshotData ->SnapShotData4 ==
   Test_faultSnapshotData->SnapShotData4))
{

 TestCaseResult = TRUE ;
}
else
{
   Failcount++ ;
}

 /* Send test file name to result buffer for results verification */
Print_Test_Filename("Activate_Shutdown_Per_Func.c");

 /* Send test case ID to the result buffer for results verification */
Print_Test_Case_ID(CurrentTestCase);

 Print_Test_Case_Values(TRUE, TRUE,16, INVOKED_SS_FaultHandler, TestCaseResult);

 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(TestCaseResult);

Print_Test_Case_Values(SS_FaultHandler_faultHandlerExitType, TRUE,
                        16, Test_faultHandlerExitType ,
                       ((SS_FaultHandler_faultHandlerExitType ==
                       Test_faultHandlerExitType)? TRUE : FALSE));

 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultHandlerExitType ==
                         Test_faultHandlerExitType) ? TRUE : FALSE));


 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData1, TRUE,
                        16, Test_faultSnapshotData->SnapShotData1 ,(
                        (SS_FaultHandler_faultSnapshotData->SnapShotData1
                        == Test_faultSnapshotData->SnapShotData1) ?
                        TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData1
                        == Test_faultSnapshotData->SnapShotData1)
                        ? TRUE : FALSE));

 Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData2, TRUE,
                        16, Test_faultSnapshotData->SnapShotData2 ,
                        ((SS_FaultHandler_faultSnapshotData->SnapShotData2
                        == Test_faultSnapshotData->SnapShotData2)
                        ? TRUE : FALSE));
 /* print results for the test case PASSED/FAILED */
 Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData2
                        == Test_faultSnapshotData->SnapShotData2)
            ? TRUE : FALSE));

Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData3, TRUE,
                      16, Test_faultSnapshotData->SnapShotData3 ,
                      ((SS_FaultHandler_faultSnapshotData->SnapShotData3
                      == Test_faultSnapshotData->SnapShotData3)
                      ? TRUE : FALSE));
/* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData3
                      == Test_faultSnapshotData->SnapShotData3)
                      ? TRUE : FALSE));

Print_Test_Case_Values(SS_FaultHandler_faultSnapshotData->SnapShotData4, TRUE,
                       16, Test_faultSnapshotData->SnapShotData4 ,
                       ((SS_FaultHandler_faultSnapshotData->SnapShotData4
                       == Test_faultSnapshotData->SnapShotData4)
                       ? TRUE : FALSE));
/* print results for the test case PASSED/FAILED */
Print_Test_Case_Result(((SS_FaultHandler_faultSnapshotData->SnapShotData4
                       == Test_faultSnapshotData->SnapShotData4)
                       ? TRUE : FALSE));

TestCase++;

/* Mark the test in progress. */
retStatus = COMPLETED;

                break;
   } /* end of case 3 */

 }/* end of switch */

   if(retStatus == COMPLETED)
   {
       TestCase = 0;
   }
    /* Return the Status */
    return retStatus;

}
