/*******************************************************************************
**
**                                  WARNING
**
**   Copyright Hamilton Sundstrand Corporation. This document is the property
**   of Hamilton Sundstrand Corporation ("HS"). You may not possess, use,
**   copy or disclose this document or any information in it, for any purpose,
**   including without limitation, to design, manufacture or repair parts,
**   or obtain any government approval to do so, without HS's express written
**   permission. Neither receipt nor possession of this document alone, from
**   any source, constitutes such permission. Possession, use, copying or
**   disclosure by anyone without HS's express written permission is
**   not authorized and may result in criminal and/or civil liability.
**
********************************************************************************
**
**          *****************************************************
**          *   Stubs.c                                         *
**          *****************************************************
**
**
**   Test Identification: Stubs.c for BPCU_Active_Shutdown.java
**
**   Software Configuration Index (SCI): DS10596/224
**
********************************************************************************
**
**   Author(s): Raghavendra.DK
**
********************************************************************************
**                           History
**
**  Starteam:
**   $Log:
**    3    1112 - 787-9 ESS 1.2         8/14/2012 10:28:13 AM  Christopher D.
**         Schin Updated per AIs
**    2    1112 - 787-9 ESS 1.1         8/6/2012 2:46:42 PM    Jonathan R.
**         Grommes Updated
**    1    1112 - 787-9 ESS 1.0         7/30/2012 9:43:51 AM   Brian L. Trumpy
**         SITE MT RBTs developed by HS for CR4538
**   $
**   $NoKeywords$
**
**  MKS:
**    $Log: stubs.c $
**    Revision 1.2  2013/09/06 10:52:52  keshavr
**    CR5026 : Updated the stub for BT_WD_Trigger.
**    Revision 1.1  2013/09/06 10:52:52  keshavr
**    CR5026: Added Stub for BT_WD_Trigger function.
**    Revision 1.1  2012/08/14 10:26:54  aaegddb
**    Initial revision
**
********************************************************************************
**
**   Test Support Environment: DS10386/515
**
********************************************************************************
**
**   Requirements Tested:
**      SWRD:None
**      SWDD:
**       REQ:GW_BPCU_SWDD-20896
**
********************************************************************************
**
**   Certification Level:   DO-178B  Level A
**
********************************************************************************
**
**     Assumptions and Constraints:
**     None
**
******************************************************************************
**
**     Criteria for Evaluating Results:
**         Refer the generated .res(result) file for PASS/FAIL status.
**
******************************************************************************/

#include "BT/BT_APIs.h"
#include "SS/SS_Types.h"
#include "SS/SS_FaultHandler.h"
#include "SS/SS_FaultHandlerExitTypes.h"

SS_U32  SS_FaultHandler_faultHandlerExitType;
SS_U32  SS_FaultHandler_faultCode;
SS_FAULT_SNAPSHOT_DATA *SS_FaultHandler_faultSnapshotData;
SS_FAULT_SNAPSHOT_DATA test_SS_FaultHandler_faultSnapshotData;
unsigned int INVOKED_SS_FaultHandler;
SS_U32 Test_Call;
SS_BOOL BT_WD_Trigger_Invoked;

void SS_FaultHandler(
    SS_U32 faultHandlerExitType,
    SS_U32 faultCode,
    SS_FAULT_SNAPSHOT_DATA *faultSnapshotData
)
{
   INVOKED_SS_FaultHandler = 1;
   SS_FaultHandler_faultHandlerExitType = faultHandlerExitType;
   SS_FaultHandler_faultCode = faultCode;
   SS_FaultHandler_faultSnapshotData = &test_SS_FaultHandler_faultSnapshotData;
   SS_FaultHandler_faultSnapshotData ->SnapShotData1 =
                                       faultSnapshotData->SnapShotData1;
   SS_FaultHandler_faultSnapshotData ->SnapShotData2 =
                                       faultSnapshotData->SnapShotData2;
   SS_FaultHandler_faultSnapshotData ->SnapShotData3 =
                                       faultSnapshotData->SnapShotData3;
   SS_FaultHandler_faultSnapshotData ->SnapShotData4 =
                                       faultSnapshotData->SnapShotData4;

}


void BT_WD_Trigger( void )
{

BT_WD_Trigger_Invoked = CSA_TRUE;

return;

}
