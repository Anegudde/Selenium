/*****************************************************************************
**
**                                  WARNING
**
**  COPYRIGHT ? HAMILTON SUNDSTRAND CORPORATION. THIS DOCUMENT IS THE PROPERTY
**  OF HAMILTON SUNDSTRAND CORPORATION (HS). YOU MAY NOT POSSESS, USE, COPY
**  OR DISCLOSE THIS DOCUMENT OR ANY INFORMATION IN IT, FOR ANY PURPOSE,
**  INCLUDING WITHOUT LIMITATION, TO DESIGN, MANUFACTURE OR REPAIR PARTS, OR
**  OBTAIN ANY GOVERNMENT APPROVAL TO DO SO, WITHOUT HS?S EXPRESS WRITTEN
**  PERMISSION. NEITHER RECEIPT NOR POSSESSION OF THIS DOCUMENT PERMISSION.
**  NEITHER RECEIPT NOR POSSESSION OF THIS DOCUMENT ALONE, FROM ANY SOURCE,
**  CONSTITUTES SUCH PERMISSION. POSSESSION, USE, COPYING OR DISCLOSURE BY
**  ANYONE WITHOUT HS?S EXPRESS WRITTEN PERMISSION IS NOT AUTHORIZED AND MAY
**    RESULT IN CRIMINAL AND/OR CIVIL LIABILITY.
**
******************************************************************************
**
**
**             ********************************************
**             *       GW_Activate_Shutdown.java        *
**             ********************************************
**
**
**      Test Identification: GW_Activate_Shutdown.java
**
**      Software Configuration Index (SCI): DS10596/224
**
********************************************************************************
**
**   Author(s): RAGHAVENDRA.DK
**
********************************************************************************
**                           History
**
**  Starteam:
**   $Log:
**    3    1112 - 787-9 ESS 1.2         8/14/2012 10:28:13 AM  Christopher D.
**         Schin Updated per AIs
**    2    1112 - 787-9 ESS 1.1         8/6/2012 2:46:42 PM    Jonathan R.
**         Grommes Updated
**    1    1112 - 787-9 ESS 1.0         7/30/2012 9:43:51 AM   Brian L. Trumpy
**         SITE MT RBTs developed by HS for CR4538
**   $
**   $NoKeywords$
**
**  MKS:
**    $Log: GW_Activate_Shutdown.java $
**    Revision 1.2  2012/12/19 21:20:43  aaeearn
**    CR4739
**    Revision 1.1  2012/08/14 10:26:52  aaegddb
**    Initial revision
**
******************************************************************************
**
**     Test Support Environment: DS10386/515
**
******************************************************************************
**
**     Requirements Tested:
**      SWRD:None
**      SWDD:
**       REQ:GW_BPCU_SWDD-20896
**
******************************************************************************
**
**     Certification Level: DO-178B Level A
**
******************************************************************************
**
**     Assumptions and Constraints:
**     None
**
******************************************************************************
**
**     Criteria for Evaluating Results:
**         Refer the generated .res(result) file for PASS/FAIL status.
**
******************************************************************************/
package tIO_Unit_Test;

import junit.framework.Test;

import org.eclipse.hyades.test.common.junit.DefaultTestArbiter;
import org.eclipse.hyades.test.common.junit.HyadesTestCase;
import org.eclipse.hyades.test.common.junit.HyadesTestSuite;

import comms.CommsPortTLP;
import comms.Logger;
import comms.ResultFormatter;

import Coverage.TestRT;
import tIO_Unit_Test.GlobalDataUT;
import IO_Unit_Test.IO_Unit_Test;
import Products.PRODUCT_787_EPGS_MT;


/**
 * Generated code for the test suite <b>GW_Activate_Shutdown</b> located at
 * <i>/JavaVESA_Client/src/Unit_Test/GW_Activate_Shutdown.testsuite</i>.
 */
public class GW_Activate_Shutdown extends HyadesTestCase {
    static CommsPortTLP comms;
    static PRODUCT_787_EPGS_MT unit;
    public static TestRT Cov_RT;

    /**
     * testScriptHeader
     * @throws Exception
     */
    public void testScriptHeader() throws Exception {
            String name1 =        CommUtil.Convert.Trim("$RCSfile: GW_Activate_Shutdown.java $");
    String name =        name1.replace("$", " ");
    String version1 =     CommUtil.Convert.Trim("$Revision: 1.2 $");
    String version =     version1.replace("$", " ");

    Logger.println("\n"+
    "**   Test Identification: GW_Activate_Shutdown.java                    \n"+
    "**                                                                     \n"+
    "**   This file's version information::                                 \n"+
    "**                $RCSfile: GW_Activate_Shutdown.java $                                          \n"+
    "**                $Revision: 1.2 $                                         \n"+
    "**                                                                     \n"+
    "**   Results generated from following Test Script:                     \n"+
    "**            "+name+"                                                 \n"+
    "**            "+version+"                                              \n"+
    "**   Software Configuration Index (SCI):DS10596/224                    \n"+
    "**                                                                     \n"+
    "**                                                                     \n"+
    "**   Software Level: A                                                 \n"+
    "**                                                                     \n"+
    "***********************************************************************\n"+
    "**                                                                     \n"+
    "**      Author(s): RAGHAVENDRA.DK                                      \n"+
    "***********************************************************************\n"+
    "**                           History                                   \n"+
    "**                                                                     \n"+
    "**   Date        Initials      Problem Description                     \n"+
    "**   06-Aug-12      DKR         Initial version as                     \n"+
    "***********************************************************************\n"+
    "**                                                                     \n"+
    "**     Test Support Environment: DS10386/523                           \n"+
    "**                                                                     \n"+
    "***********************************************************************\n"+
    "**                                                                     \n"+
    "**     Requirements Tested:                                            \n"+
    "**                      REQ:GW_BPCU_SWDD-20896                         \n"+
    "**                                                                     \n"+
    "***********************************************************************\n"+
    "**                                                                     \n"+
    "**    Units Tested:Active_Shutdown.c                                   \n"+
    "**                                                                     \n"+
    "***********************************************************************\n"+
    "**                                                                     \n"+
    "** Assumptions and Constraints:                                        \n"+
    "**     NONE                                                            \n"+
    "**                                                                     \n"+
    "**                                                                     \n"+
    "***********************************************************************\n"+
    "**     Criteria for Evaluating Results:                                \n"+
    "**                                                                     \n"+
    "**     All data listed under Expected Outputs must exactly match       \n"+
    "**     the listed result or range expressed.                           \n"+
    "**                                                                     \n"+
    "***********************************************************************");

    }

    static IO_Unit_Test Unit_Test = null;
    String ClassName              = "GW_Activate_Shutdown";
    String Cov_File_Name          = "GW_Activate_Shutdown";
    String ClassName1             = "GW_Activate_Shutdown";

    /*Getting the Current working directory */
   String curDir       = System.getProperty("user.dir");
   String Cov_FilePath = curDir + "\\SITE_Test_Results\\" + ClassName1 + ".tio";

    public GW_Activate_Shutdown(String name) {
        super(name);
    }

    /**
     * Returns the JUnit test suite that implements the <b>GW_Activate_Shutdown
     </b> definition.
     */
    public static Test suite() {
        HyadesTestSuite gW_Activate_Shutdown = new HyadesTestSuite(
                "GW_Activate_Shutdown");
        gW_Activate_Shutdown.setArbiter(DefaultTestArbiter.INSTANCE).setId(
                "A1E1DFE503B3DED0F3C8E43764656139");
        gW_Activate_Shutdown.addTest(new GW_Activate_Shutdown("testHeader")
                .setId("A1E1DFE5088208B0F3C8E43764656139").setTestInvocationId(
                        "A1E1DFE51DC9BA10F3C8E43764656139"));
        gW_Activate_Shutdown.addTest(new GW_Activate_Shutdown(
                "testScriptHeader").setId("A1E1DFE50CC5F3F0F3C8E43764656139")
                .setTestInvocationId("A1E1DFE51DCC0400F3C8E43764656139"));
        gW_Activate_Shutdown.addTest(new GW_Activate_Shutdown("tc1").setId(
                "A1E1DFE512C54AD0F3C8E43764656139").setTestInvocationId(
                "A1E1DFE51DCE7500F3C8E43764656139"));
        gW_Activate_Shutdown.addTest(new GW_Activate_Shutdown("testFooter")
                .setId("A1E1DFE515C03B50F3C8E43764656139").setTestInvocationId(
                        "A1E1DFE51DCE7501F3C8E43764656139"));
        return gW_Activate_Shutdown;
    }

    /**
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
    }

    /**
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
    }

    /**
     * testHeader
     * @throws Exception
     */
    public void testHeader() throws Exception {
                 comms = new CommsPortTLP();

            /*Open the port and the Result file */
      unit = new PRODUCT_787_EPGS_MT(comms, curDir + "\\SITE_Test_Results\\"
             + ClassName + ".res",Cov_FilePath,"GW_Activate_Shutdown");

    }
/*******************************************************************************
**   Test Case: 1
**
**   Requirements under test: REQ:GW_BPCU_SWDD-20896
**
**
**    Normal/robustness test: Normal
**
**    Objective:The following verifies that  Active
**              Active_Shutdown Shall call the
**              Shall call the SS_FaultHandler and
**              Snapshot data holds the
**              intermediate value
********************************************************************************
**
**
********************************************************************************
**   Test Case: 2
**
**   Requirements under test: REQ:GW_BPCU_SWDD-20896
**
**
**    Normal/robustness test: Normal
**
**   Objective:The following verifies that Active_Shutdown
**             Shall call the SS_FaultHandler and Snapshot
**             data holds the Minimum value
********************************************************************************
**
**
********************************************************************************
**   Test Case: 3
**
**   Requirements under test: REQ:GW_BPCU_SWDD-20896
**
**
**    Normal/robustness test: Normal
**
**   Objective:The following verifies that Active_Shutdown
**             Shall call the SS_FaultHandler and Snapshot
**             data holds the Maximum value
*******************************************************************************/

    /**
     * tc1
     * @throws Exception
     */
    public void tc1() throws Exception {

    unit.Execute_TestGroups((byte)GlobalDataUT.
    TEST_NAME.ACTIVATE_SHUTDOWN_PER_FUNC.ordinal());

    }

    /**
     * testFooter
     * @throws Exception
     */
    public void testFooter() throws Exception {

        /* Close the CSCI connection */
        unit.CSCI_Close();

    }

}
