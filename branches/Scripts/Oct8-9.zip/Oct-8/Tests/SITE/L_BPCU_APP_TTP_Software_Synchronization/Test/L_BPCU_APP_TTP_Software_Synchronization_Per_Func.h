/********************************************************************************
**
**                                  WARNING
**
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
*******************************************************************************
**
**
**     Test Identification: L_BPCU_APP_TTP_Software_Synchronization_Per_Func.h
**
**     This file's version information ::
**     $RCSfile: L_BPCU_APP_TTP_Software_Synchronization_Per_Func.h $
**     $Revision: 1.1 $
**
** Software Configuration Index (SCI): DS10596/222
**
** Software Level: A
**
*******************************************************************************
**
**      Author(s): Anushree.MS
**
*******************************************************************************
**                            History
**
**        Date        Initials   Description
**
**        01-Oct-12    AMS       Initial version 
******************************************************************************
**
**     Test Support Environment: DS10596/225
**
*****************************************************************************
**
**Requirements Tested: SWRD:BPCU_SWRD-22681
**                          BPCU_SWRD-22687
**                          BPCU_SWRD-22688
**                          BPCU_SWRD-22690
**                          BPCU_SWRD-22692
**                          BPCU_SWRD-22693
**                          BPCU_SWRD-22695
**                          BPCU_SWRD-22696 
**                          BPCU_SWRD-22697
**                          BPCU_SWRD-36752 
**
**                      SWDD:787_BPCU_SWDD-2369
**                           787_BPCU_SWDD-2370
**                           787_BPCU_SWDD-2372
**                           787_BPCU_SWDD-2374
**                           787_BPCU_SWDD-2376
**                           787_BPCU_SWDD-2377
**                           787_BPCU_SWDD-2378
**                           787_BPCU_SWDD-2379
**                           787_BPCU_SWDD-2380
**                           787_BPCU_SWDD-30059
**                           787_BPCU_SWDD-3192
**                           787_BPCU_SWDD-23713
**                           787_BPCU_SWDD-23714
**                           787_BPCU_SWDD-23715
*****************************************************************************
**
** Units Tested: TTP_Software_Synchronization.c
**
******************************************************************************
**
**     Assumptions and Constraints:
**
**   Logic BPCU SWDD traced to SWRD has been referred
**   to realize the test cases of this test script.
******************************************************************************
**
**     Criteria for Evaluating Results:
**
**     All data listed under Expected Outputs must exactly match
**     the listed result or range expressed.
**
*******************************************************************************
*/

#include "VesaModuleTestExecutive.h"
#include "Verify_Output.h"

#ifndef L_BPCU_APP_TTP_Software_Synchronization_PER_FUNC_H
#define L_BPCU_APP_TTP_Software_Synchronization_PER_FUNC_H

TESTSTATUS L_BPCU_APP_TTP_Software_Synchronization_Per_Func(void);

#endif

/********END of L_BPCU_APP_TTP_Software_Synchronization_Per_Func.h*************/
