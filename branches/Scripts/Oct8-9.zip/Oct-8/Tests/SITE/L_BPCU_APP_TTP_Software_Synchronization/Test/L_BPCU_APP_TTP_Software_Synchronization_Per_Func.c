/****************************************************************************
**
**                                 WARNING
**  Copyright �  Hamilton Sundstrand Corporation. This document is the
**  property of Hamilton Sundstrand Corporation (HS). You may not possess,
**  use, copy or disclose this document or any information in it, for any
**  purpose, including without limitation, to design, manufacture or repair
**  parts, or obtain any government approval to do so, without HSC's express
**  written permission. Neither receipt nor possession of this document alone,
**  from any source, constitutes such permission. Possession, use, copying or
**  disclosure by anyone without HSC's express written permission is not
**  authorized and may result in criminal and/or civil liability.
**
**
****************************************************************************
**
** Test Identification: L_BPCU_APP_TTP_Software_Synchronization_Per_Func.c
**
**     This file's version information ::
**     $RCSfile: L_BPCU_APP_TTP_Software_Synchronization_Per_Func.c $
**     $Revision: 1.4 $
**
** Software Configuration Index (SCI): DS10596/222
**
** Software Level: A
**
*****************************************************************************
**
** Author(s): Anushree.MS / Raghavendra Keshvamurthy
**
******************************************************************************
**
**                                 History
**
**        Date        Initials   Description
**
**        01-Oct-12      AMS     Initial version
**        21-AUG-13      RDK     Updated for CR5011
**
******************************************************************************
**
** Test Support Environment: DS10596/225
**
*****************************************************************************
**
**Requirements Tested: SWRD:BPCU_SWRD-22681
**                          BPCU_SWRD-22687
**                          BPCU_SWRD-22688
**                          BPCU_SWRD-22690
**                          BPCU_SWRD-22692
**                          BPCU_SWRD-22693
**                          BPCU_SWRD-22695
**                          BPCU_SWRD-22696 
**                          BPCU_SWRD-22697
**                          BPCU_SWRD-36752 
**
**                      SWDD:787_BPCU_SWDD-2369
**                           787_BPCU_SWDD-2370
**                           787_BPCU_SWDD-2372
**                           787_BPCU_SWDD-2374
**                           787_BPCU_SWDD-2376
**                           787_BPCU_SWDD-2377
**                           787_BPCU_SWDD-2378
**                           787_BPCU_SWDD-2379
**                           787_BPCU_SWDD-2380
**                           787_BPCU_SWDD-30059
**                           787_BPCU_SWDD-3192
**                           787_BPCU_SWDD-23713
**                           787_BPCU_SWDD-23714
**                           787_BPCU_SWDD-23715
**                           787_BPCU_SWDD-38485
**                           787_BPCU_SWDD-38486
*****************************************************************************
**
** Units Tested: TTP_Software_Synchronization.c
**
******************************************************************************
**
** Assumptions and Constraints :
**
**   Logic BPCU SWDD traced to SWRD has been referred
**   to realize the test cases of this test script.
*****************************************************************************
**
** Criteria for Evaluating Results:
**   All data listed under Expected Outputs must exactly match the listed
**   result or range expressed.
**
*****************************************************************************/

#include "OS/OS_APIs.h"
#include "SS/SS_APIs.h"
#include "App_Get_DEC.h"
#include "App_Set_DEC.h"
#include "ttp_initialization.h"
#include "ttp_network_preference.h"
#include "L_BPCU_APP_TTP_Software_Synchronization_Per_Func.h"
#include "SS_INTR_DISABLE.H"
#include "SS_INTR_ENABLE.H"



/*Variable stubbing starts here*/
typedef struct
{
    tt_ttp_Protocol_State	ppdn1_protocol_state;
    tt_ttp_Protocol_State	ppdn2_protocol_state;
    ubyte1					primary_ttp_network;
    ubyte1					cluster_round_num;
    ubyte2					cluster_slot_num;
    ubyte1					round_slot_num;
    SS_U32					decr_time;
    ubyte2					sw_sync_shift;
    ubyte1					sw_sync_state;
    ubyte2					sw_sync_run_counter;
    ubyte2					sw_out_sync_counter;

} test_sw_sync;

extern test_sw_sync sw_sync;
extern ubyte1	TDMA_Round_Number_Valid;



SS_U32 LruID;
SS_U32 Counter_5ms_Tasks;

struct _tt_tdc_FCL_Contr_Frame_Config v1_tdc_FCL_Contr_Frame_Config;
struct _tt_tdc_FCL_Contr_Frame_Config v2_tdc_FCL_Contr_Frame_Config;

const tt_LRU_Descriptor LRU_Config [] =
{
    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}},

    /* LRU #1 */
    { .frame_copy_controller_config = {&v1_tdc_FCL_Contr_Frame_Config,
                                       &v2_tdc_FCL_Contr_Frame_Config}}


}; /*End of variable stubbing*/

/* Global Test Variables */
tt_ttp_Protocol_State	ppdn1_protocol_state;
tt_ttp_Protocol_State	ppdn2_protocol_state;

tt_ttp_C_State ppdn_c_state;
ubyte1 SWITCH_SLOT;

ubyte1 Primary_TTP_Network;

ubyte2 sw_sync_shift;
ubyte2 round_slot;
ubyte2 ppdn_global_time;
ubyte2 ppdn_round_slot_time;

unsigned int decr_time;
extern ubyte1 SW_Sync_State;

extern BOOL tt_ttp_get_c_state_Invoked;
extern BOOL tt_ttp_get_global_time_Invoked;
extern BOOL SS_INTR_Disable_Invoked;
extern SS_INTR_DISABLE_MASK SS_INTR_Disable_DisableMSR;
extern BOOL SS_INTR_Enable_Invoked;
extern SS_INTR_ENABLE_MASK SS_INTR_Enable_EnableMSR;

extern  CSA_U32 Test_Flag;
extern  CSA_U32 Test_Call;
extern  CSA_U32 Test_Flag1;

#define OUT_SYNC	2
#define IN_SYNC		1

TESTSTATUS L_BPCU_APP_TTP_Software_Synchronization_Per_Func(void)
{

    /* For switching into the different test cases */
    static short   TestCase ;

    /* To hold the Test status */
    TESTSTATUS     Status = IN_PROGRESS;

    /* To hold and print the test case results */
    VER_BOOLEAN    TestCaseResult;

    unsigned int Failcount, Exp_Test_flag;

    switch (TestCase)
    {
        case 0:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 1                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22687                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22681                             ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-2369                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                ");     
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that SW_Sync_State is set to UNKNOWN and                   ");
            Print_Test_Header("**        The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are not called,when              ");
            Print_Test_Header("**        all of the following are TRUE                                       ");
            Print_Test_Header("**        1.ppdn1_protocol_stateis not Equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**        2.ppdn2_protocol_state=TT_TTP_ACTIVE                                 ");
            Print_Test_Header("**        3.Primary_TTP_Network=PPDN1                                          ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;

			  Primary_TTP_Network=PPDN1;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
    
               SW_Sync_State=PPDN1;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_FALSE)&&(tt_ttp_get_global_time_Invoked==CSA_FALSE)&&
			    (SW_Sync_State==UNKNOWN) && (SS_INTR_Disable_Invoked==CSA_FALSE) && (SS_INTR_Enable_Invoked==CSA_FALSE))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerifying that the function tt_ttp_get_c_state() is not invoked ");	
            Print_Test_Header("\nVerifying that the function tt_ttp_get_global_time() is not invoked ");				
            Print_Test_Header("\nVerification for SW_Sync_State.");		
			
            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
         
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);


			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 0 */


        case 1:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 2                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22687                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22681                             ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-2370                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");  
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                ");     
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that SW_Sync_State is set to UNKNOWN and                   ");
            Print_Test_Header("**        The functions tt_ttp_get_c_state,tt_ttp_get_global_time,           ");    
            Print_Test_Header("**        SS_INTR_DISABLE and SS_INTR_ENABLE are not called,when              ");
            Print_Test_Header("**        all of the following are TRUE                                       ");
            Print_Test_Header("**        1.ppdn1_protocol_state=TT_TTP_ACTIVE                                 ");
            Print_Test_Header("**        2.ppdn2_protocol_state not equal TT_TTP_ACTIVE                       ");
            Print_Test_Header("**        3.Primary_TTP_Network=PPDN2                                          ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=1;

			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               
               SW_Sync_State=PPDN1;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");



            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_FALSE)&&(tt_ttp_get_global_time_Invoked==CSA_FALSE)&&
			    (SW_Sync_State == UNKNOWN)&& (SS_INTR_Disable_Invoked==CSA_FALSE) && (SS_INTR_Enable_Invoked==CSA_FALSE))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
	
            Print_Test_Header("\nVerifying that the function tt_ttp_get_c_state() is not invoked ");	
            Print_Test_Header("\nVerifying that the function tt_ttp_get_global_time() is not invoked ");	
            Print_Test_Header("\nVerification for SW_Sync_State.");				

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 1 */


        case 2:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 3                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22687                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22690                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22695                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22681                             ");
            Print_Test_Header("**                                BPCU_SWRD-36752                              ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-2370                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-2376                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-2379                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-30059                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-23713                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-23714                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-23715                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2.SW Sync Shift is calculated in the following manner           ");
            Print_Test_Header("**               Delta1 = Current global time - Start time of current slot.    ");
            Print_Test_Header("**               Delta2 = Initial decrementer setting - Current decrementer    ");
            Print_Test_Header("**               register value SW Sync Shift = Delta1 - Delta2and             ");
            Print_Test_Header("**             3.When the SW Sync Shift is outside the SW Sync Window          ");
            Print_Test_Header("**               and greater than zero, the decrementer register               ");
            Print_Test_Header("**               value is decreased by 50 micro seconds.                       ");
            Print_Test_Header("**             4.TDMA_Round_Number_Valid is set to TRUE                        ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("** Note:To verify that                                                         ");
            Print_Test_Header("**      1.SW_Sync_State is set to OUT_SYNC                                     "); 
            Print_Test_Header("**        and  tt_ttp_get_c_state,tt_ttp_get_global_time                      ");
            Print_Test_Header("**        SS_INTR_ENABLE  and SS_INTR_DISABLE functions are called when        ");
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**       2. SW_Sync_State = OUT_SYNC                                           ");
            Print_Test_Header("**          decr_time = decr_time - SW_SYNC_ADJ ,when SW Sync Shift is not     ");
            Print_Test_Header("**          SW_SYNC_ZONE                                                       ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=1;
			  Primary_TTP_Network=PPDN2;
               Test_Call=0;
            /* Setting other than expected value */
			   
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
               
               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
			   TDMA_Round_Number_Valid = FALSE;
			   				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (TDMA_Round_Number_Valid == TRUE)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function is Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");				

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (TRUE, TRUE, 16, TDMA_Round_Number_Valid ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);
		   
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 2 */
		  
		  
        case 3:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 4                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22687                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22690                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22688                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22693                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22681                             ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-2370                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-2376                          ");                                    
            Print_Test_Header("**                                 787_BPCU_SWDD-2378                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-2372                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**               SW Sync Shift be calculated in the following manner           ");
            Print_Test_Header("**             2.Delta1 = Current global time - Start time of current slot.    ");
            Print_Test_Header("**               Delta2 = Initial decrementer setting - Current decrementer    ");
            Print_Test_Header("**               register value SW Sync Shift = Delta1 - Delta2and             ");
            Print_Test_Header("**             3.When the SW Sync Shift is within SW Sync Window and less than ");
            Print_Test_Header("**               or equal to SW Sync Window center, decrementer register value ");
            Print_Test_Header("**               is increased by half the difference between the SW Sync Window");
            Print_Test_Header("**                center and SW Sync Shift plus one macro tick.                ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The Functions tt_ttp_get_c_state,tt_ttp_get_global_time           ");    
            Print_Test_Header("**          SS_INTR_ENABLE and SS_INTR_DISABLE are called when:               ");
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**        2.SW_Sync_State = IN_SYNC and sw_sync_tune =                         ");
            Print_Test_Header("**         (SW_SYNC_CENTER - sw_sync_shift + 1) / 2,                           ");
            Print_Test_Header("**         decr_time = decr_time + sw_sync_tune. when sw_sync_shift less than  ");   
            Print_Test_Header("**         SW_SYNC_ZONE and sw_sync_shift is not greater than SW_SYNC_CENTER   ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=2;
			  Primary_TTP_Network=PPDN2;
               Test_Call=0;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
               
               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == IN_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }
			
			
            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");				
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");		
            Print_Test_Header("\nVerification for SW_Sync_State.");				

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (IN_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 3 */
		  
      case 4:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 5                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:BPCU_SWRD-22687                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22690                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22688                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22692                             ");
            Print_Test_Header("**                                 BPCU_SWRD-22681                             ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-2370                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-2376                          ");                                    
            Print_Test_Header("**                                 787_BPCU_SWDD-2377                          ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured                       ");
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**               SW Sync Shift be calculated in the following manner           ");
            Print_Test_Header("**             2.Delta1 = Current global time - Start time of current slot.    ");
            Print_Test_Header("**               Delta2 = Initial decrementer setting - Current decrementer    ");
            Print_Test_Header("**               register value SW Sync Shift = Delta1 - Delta2and             ");
            Print_Test_Header("**             3.When the SW Sync Shift is within SW Sync Window and greater   ");
            Print_Test_Header("**               than SW Sync Window center, decrementer register value        ");
            Print_Test_Header("**               is decreased by half the difference between the SW Sync Shift ");
            Print_Test_Header("**                and SW Sync Window center plus one macro tick.               ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The Functions tt_ttp_get_c_state,tt_ttp_get_global_time           ");    
            Print_Test_Header("**          SS_INTR_ENABLE and SS_INTR_DISABLE are called when:               ");
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2                                  ");
            Print_Test_Header("**        2.SW_Sync_State = IN_SYNC and sw_sync_tune =                         ");
            Print_Test_Header("**         (sw_sync_shift - SW_SYNC_CENTER + 1) / 2,                           ");
            Print_Test_Header("**         decr_time = decr_time - sw_sync_tune. when sw_sync_shift less than  ");   
            Print_Test_Header("**         SW_SYNC_ZONE and sw_sync_shift is greater than SW_SYNC_CENTER       ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=3;
			  Primary_TTP_Network=PPDN2;
               Test_Call=0;
            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");
            Print_Test_Header("\nVerification for SW_Sync_State.");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == IN_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (IN_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 4 */



        case 5:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 6                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-22687                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22696                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22681                            ");
            Print_Test_Header("**                            SWDD: 787_BPCU_SWDD-2370                         ");
            Print_Test_Header("**                                  787_BPCU_SWDD-2380                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occured when the TTP          ");
            Print_Test_Header("**               controller for the Primary_TTP_Network is in the Active state,");
            Print_Test_Header("**             2.When the SW Sync Shift is outside the SW Sync Window          ");
            Print_Test_Header("**               and less than zero, the decrementer register                  ");
            Print_Test_Header("**               value is increased by 50 micro seconds.                       ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       "); 
            Print_Test_Header("**        1.The Functions tt_ttp_get_c_state,tt_ttp_get_global_time           ");    
            Print_Test_Header("**          SS_INTR_ENABLE and SS_INTR_DISABLE are called when:               ");
            Print_Test_Header("**         1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                   ");
            Print_Test_Header("**         2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                       ");
            Print_Test_Header("**         3.Primary_TTP_Network equal PPDN2 and the                           ");
            Print_Test_Header("**        2.SW_Sync_State = OUT_SYNC and decr_time = decr_time + SW_SYNC_ADJ   ");
            Print_Test_Header("**          when delta1 is not greater than delta2                             ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=1;
			  Primary_TTP_Network=PPDN2;
			  Test_Call=1;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=0;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }


            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");
            Print_Test_Header("\nVerification for SW_Sync_State.");

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 5 */


        case 6:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 7                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-22687                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22681                            ");
            Print_Test_Header("**                            SWDD: 787_BPCU_SWDD-2369                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is  occured         ");
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is in       ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**   Note:To verify that                                                       ");
            Print_Test_Header("**           1.Primary_TTP_Network equals PPDN1 and                            ");
            Print_Test_Header("**             PPDN1_Protocol_State equals TT_TTP_ACTIVE then                  ");
            Print_Test_Header("**             The tt_ttp_get_c_state function is called and PPDN1 network c   ");
            Print_Test_Header("**             state is assigned to ppdn_c_state. The tt_ttp_get_global_time   ");
            Print_Test_Header("**             function is called and PPDN1 network global time is assigned    ");
            Print_Test_Header("**             to ppdn_global_time.                                            ");
            Print_Test_Header("**           2.SW_Sync_State set to OUT_SYNC                                  ");
            Print_Test_Header("**           3.SS_INTR_ENABLE and SS_INTR_DISABLE are called.                  ");
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=1;

			  Primary_TTP_Network=PPDN1;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SW_Sync_State=PPDN1;
				LruID=1;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;
               
          /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			     (SW_Sync_State==OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");
            Print_Test_Header("\nVerification for SW_Sync_State.");
			
			
            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

			
            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;

            break;
          }/* end of case 6 */



        case 7:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 8                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-22687                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22697                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22681                            ");
            Print_Test_Header("**                            SWDD: 787_BPCU_SWDD-2370                         ");
            Print_Test_Header("**                                  787_BPCU_SWDD-2374                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that                                                  ");
            Print_Test_Header("**             1.The Software synchronization is occurred                      ");
            Print_Test_Header("**               when the TTP controller for the Primary_TTP_Network is in     ");
            Print_Test_Header("**               the Active state,                                             ");
            Print_Test_Header("**             2.When the current round slot number is not equal to the        ");
            Print_Test_Header("**               configured slot number, the decrementer register              ");
            Print_Test_Header("**               value is not decreased by 50 micro seconds.                   ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that                                                       ");
            Print_Test_Header("**        1.The Functions tt_ttp_get_c_state,tt_ttp_get_global_time           ");    
            Print_Test_Header("**          SS_INTR_ENABLE and SS_INTR_DISABLE are called when:               ");
            Print_Test_Header("**          1.ppdn1_protocol_state not equal to TT_TTP_ACTIVE                  ");
            Print_Test_Header("**          2.ppdn2_protocol_state equal to TT_TTP_ACTIVE                      ");
            Print_Test_Header("**          3.Primary_TTP_Network equal PPDN2 and                              ");
            Print_Test_Header("**       2.SW_Sync_State is set to OUT_SYNC                                    ");
            Print_Test_Header("**         when round_slot_num is not equal to SWITCH_SLOT                     "); 
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=0;
              Test_Flag1=4;
			  Primary_TTP_Network=PPDN2;

            /* Setting other than expected value */
               tt_ttp_get_c_state_Invoked=CSA_FALSE;
			   tt_ttp_get_global_time_Invoked=CSA_FALSE;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;
               SS_INTR_Disable_DisableMSR=SS_INTR_DISABLE_ME;
               SS_INTR_Enable_EnableMSR=SS_INTR_ENABLE_ME;

               SW_Sync_State=PPDN1;
			   SWITCH_SLOT=3;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
            Print_Test_Header("\nVerification for tt_ttp_get_c_state() Function Invocation.");
            Print_Test_Header("\nVerification for tt_ttp_get_global_time() Function Invocation.");
            Print_Test_Header("\nVerification for SW_Sync_State.");


            /* Expected and Actual values comparison */

            if ((tt_ttp_get_c_state_Invoked == CSA_TRUE)&&(tt_ttp_get_global_time_Invoked==CSA_TRUE)&&
			    (SW_Sync_State == OUT_SYNC)&& (SS_INTR_Disable_Invoked==CSA_TRUE) && (SS_INTR_Enable_Invoked==CSA_TRUE)&& (SS_INTR_Disable_DisableMSR==SS_INTR_DISABLE_ALL) && (SS_INTR_Enable_EnableMSR==SS_INTR_ENABLE_ALL))

            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_c_state_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, tt_ttp_get_global_time_Invoked ,TestCaseResult);
            Print_Test_Case_Values (OUT_SYNC, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_TRUE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_DISABLE_ALL, TRUE, 16, SS_INTR_Disable_DisableMSR ,TestCaseResult);
            Print_Test_Case_Values (SS_INTR_ENABLE_ALL, TRUE, 16, SS_INTR_Enable_EnableMSR ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;



            break;
          }/* end of case 7 */
		  
		  
        case 8:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 9                                                              ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD: BPCU_SWRD-22687                            ");
            Print_Test_Header("**                                  BPCU_SWRD-22681                            ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-38485                         ");
            Print_Test_Header("**                                 787_BPCU_SWDD-38486                         ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that the Software synchronization is not occured      ");
            Print_Test_Header("**             when the TTP controller for the Primary_TTP_Network is not in   ");
            Print_Test_Header("**             the Active state                                                ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Note:To verify that SW_Sync_State is set to UNKNOWN , when                ");
            Print_Test_Header("**        1.ppdn1_protocol_state is not Equal to TT_TTP_ACTIVE                 ");
            Print_Test_Header("**        2.ppdn2_protocol_state is not Equal toTT_TTP_ACTIVE                  ");
            Print_Test_Header("**        3.Primary_TTP_Network=PPDN1                                          ");
            Print_Test_Header("**        4.SS_INTR_ENABLE and SS_INTR_DISABLE are not invoked              ");
            Print_Test_Header("****************************************************************************/  ");


            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Initialisation of variables */
              Test_Flag=2;

			  Primary_TTP_Network=PPDN1;

            /* Setting other than expected value */
               SW_Sync_State=PPDN1;
				LruID=1;
               SS_INTR_Disable_Invoked=CSA_FALSE;
			   SS_INTR_Enable_Invoked=CSA_FALSE;

               /* Function under test Invocation */
            TTP_Software_Synchronization();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");



            /* Expected and Actual values comparison */

            if (SW_Sync_State==UNKNOWN && (SS_INTR_Disable_Invoked==CSA_FALSE) && (SS_INTR_Enable_Invoked==CSA_FALSE))
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* Printing Variable under test */

            Print_Test_Header("\nVerification for SW_Sync_State.");

            /* print the expected and actual values in the result file */

            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Disable_Invoked ,TestCaseResult);
            Print_Test_Case_Values (CSA_FALSE, TRUE, 16, SS_INTR_Enable_Invoked ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);		  

			/*Increment the test case number to point to the following test case*/
              TestCase++;


              /* When test is in progress, set the variable Status to IN_PROGRESS */
              Status = IN_PROGRESS;


            break;
          }/* end of case 8 */			
			

        case 9:
        {
            Print_Test_Header("/****************************************************************************  ");
            Print_Test_Header("**   Test Case: 10                                                             ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Requirements under test: SWRD:None                                        ");                         
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**                            SWDD:787_BPCU_SWDD-3192                          ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Normal/robustness test: Normal                                            ");
            Print_Test_Header("**                                                                             ");
            Print_Test_Header("**   Objective:To verify that SW_Sync_State is set to UNKNOWN                  ");
            Print_Test_Header("**                                                                             ");  
            Print_Test_Header("**                                                                             ");                                                 
            Print_Test_Header("****************************************************************************/  ");

            /*Initialise the TestCaseResult to FALSE*/
            TestCaseResult = FALSE;


            /***************************************************************************/
            /* Test Input */
            /***************************************************************************/

            /* Setting other than expected value */
               SW_Sync_State=PPDN1;
				LruID=1;
            /* Function under test Invocation */
            TTP_Software_Synchronization_Init();

            Print_Test_Header("/***************************************************************************/ ");
            Print_Test_Header("/* Expected Outputs */                                                        ");
            Print_Test_Header("/***************************************************************************/ ");

            /* Send test file name to result buffer for results verification */
            Print_Test_Filename("L_BPCU_APP_TTP_Software_Synchronization");

            /* Printing Variable under test */
;		
            Print_Test_Header("\nVerification for SW_Sync_State.");	


            /* Expected and Actual values comparison */

            if (SW_Sync_State == UNKNOWN)
            {
            TestCaseResult = TRUE;
            }
            else
            {
            Failcount++;
            }

            /* print the expected and actual values in the result file */
            Print_Test_Case_Values (UNKNOWN, TRUE, 16, SW_Sync_State ,TestCaseResult);

            /* print results for  the test case PASSED/FAILED */
            Print_Test_Case_Result(TestCaseResult);	


            /* While test is completed the variable is set to COMPLETED */
            Status = COMPLETED;

            break;
        }/* end of Case 9 */

    }/*End of Switch case */

/*Return the Status */
return Status;

}

/********END of L_BPCU_APP_TTP_Software_Synchronization_Per_Func.C*************/

