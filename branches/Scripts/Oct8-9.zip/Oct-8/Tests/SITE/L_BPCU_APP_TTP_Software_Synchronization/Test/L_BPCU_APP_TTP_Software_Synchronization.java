
package tIO_Unit_Test;

import junit.framework.Test;

import org.eclipse.hyades.test.common.junit.DefaultTestArbiter;
import org.eclipse.hyades.test.common.junit.HyadesTestCase;
import org.eclipse.hyades.test.common.junit.HyadesTestSuite;

import comms.CommsPortTLP;
import comms.Logger;
import comms.ResultFormatter;

import Coverage.TestRT;
import tIO_Unit_Test.GlobalDataUT;
import IO_Unit_Test.IO_Unit_Test;
import Products.PRODUCT_787_EPGS_MT;

/**
 * Generated code for the test suite <b>t_Unit_Test_PDRC_Exec</b> located at
 * <i>/JavaVESA_Client/src/Unit_Test/t_Unit_Test_PDRC_Exec.testsuite</i>.
 *
 * The Execute function for the PDRC
 */
public class L_BPCU_APP_TTP_Software_Synchronization extends HyadesTestCase {

    static CommsPortTLP comms;
    static PRODUCT_787_EPGS_MT unit;
    public static TestRT Cov_RT;

    /**
     * testScriptheader
     * TestScriptheader
     * @throws Exception
     */
    public void testScriptheader() throws Exception
    {

               String name1 = CommUtil.Convert.Trim("$RCSfile: L_BPCU_APP_TTP_Software_Synchronization.java $");
               String name =  name1.replace("$", " ");
               String version1 = CommUtil.Convert.Trim("$Revision: 1.4 $");
               String version = version1.replace("$", " ");

                /******************************************************************************\n"+
                "**                                                                            \n"+
                "**                                  WARNING                                   \n"+
                "**                                                                            \n"+
                "**  Copyright �  Hamilton Sundstrand Corporation. This document is the        \n"+
                "**  property of Hamilton Sundstrand Corporation (HS). You may not possess,    \n"+
                "**  use, copy or disclose this document or any information in it, for any     \n"+
                "**  purpose, including without limitation, to design, manufacture or repair   \n"+
                "**  parts, or obtain any government approval to do so, without HSC's express  \n"+
                "**  written permission. Neither receipt nor possession of this document alone,\n"+
                "**  from any source, constitutes such permission. Possession, use, copying or \n"+
                "**  disclosure by anyone without HSC's express written permission is not      \n"+
                "**  authorized and may result in criminal and/or civil liability.             \n"+
                "**                                                                            \n"+*/

Logger.println("\n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**                                                                     \n"+
               "**                                                                     \n"+
               "**   Test Identification: L_BPCU_APP_TTP_Software_Synchronization.java \n"+
               "**                                                                     \n"+
               "**   This file's version information::                                 \n"+
               "**    $RCSfile: L_BPCU_APP_TTP_Software_Synchronization.java $                                                     \n"+
               "**    $Revision: 1.4 $                                                     \n"+
               "**                                                                     \n"+
               "**   Results generated from following Test Script:                     \n"+
               "**    "+name+"                                                         \n"+
               "**    "+version+"                                                      \n"+
               "**                                                                     \n"+
               "**                                                                     \n"+
               "**   Software Configuration Index (SCI): DS10596/222                   \n"+
               "**                                                                     \n"+
               "**                                                                     \n"+
               "**   Software Level: A                                                 \n"+
               "**                                                                     \n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**      Author(s):  Anushree.MS                                        \n"+
               "**                  Hemalatha G                                        \n"+
               "**                  Raghavendra Keshavamurthy                         \n"+
               "***********************************************************************\n"+
               "**                           History                                   \n"+
               "**                                                                     \n"+
               "**   Date        Initials    Problem Description                       \n"+
               "**                                                                     \n"+
               "**   03-Oct-12      AMS      Initial version                           \n"+
               "**   13-Dec-12      GHL      Updated for Target run.                   \n"+               
               "**   21-Aug-12      RDK      Updated for CR5011                        \n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**     Test Support Environment:  DS10596/225                           \n"+
               "**                                                                     \n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**Requirements Tested: SWRD:BPCU_SWRD-22681                            \n"+
               "**                          BPCU_SWRD-22687                            \n"+
               "**                          BPCU_SWRD-22688                            \n"+
               "**                          BPCU_SWRD-22690                            \n"+
               "**                          BPCU_SWRD-22692                            \n"+
               "**                          BPCU_SWRD-22693                            \n"+
               "**                          BPCU_SWRD-22695                            \n"+
               "**                          BPCU_SWRD-22696                            \n"+ 
               "**                          BPCU_SWRD-22697                            \n"+  
               "**                          BPCU_SWRD-36752                            \n"+ 
               "**                                                                     \n"+
               "**                     SWDD:787_BPCU_SWDD-2369                         \n"+
               "**                          787_BPCU_SWDD-2370                         \n"+
               "**                          787_BPCU_SWDD-2372                         \n"+
               "**                          787_BPCU_SWDD-2374                         \n"+
               "**                          787_BPCU_SWDD-2376                         \n"+
               "**                          787_BPCU_SWDD-2377                         \n"+
               "**                          787_BPCU_SWDD-2378                         \n"+
               "**                          787_BPCU_SWDD-2379                         \n"+
               "**                          787_BPCU_SWDD-2380                         \n"+
               "**                          787_BPCU_SWDD-30059                        \n"+
               "**                          787_BPCU_SWDD-3192                         \n"+
               "**                          787_BPCU_SWDD-23713                        \n"+
               "**                          787_BPCU_SWDD-23714                        \n"+
               "**                          787_BPCU_SWDD-23715                        \n"+
               "**                          787_BPCU_SWDD-38485                        \n"+
               "**                          787_BPCU_SWDD-38486                        \n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**    Units Tested: TTP_Software_Synchronization.c                     \n"+
               "**                                                                     \n"+
               "***********************************************************************\n"+
               "**                                                                     \n"+
               "**Assumptions and Constraints:                                         \n"+
               "**                                                                     \n"+
               "**Logic BPCU SWDD traced to SWRD has been referred to                  \n"+
               "**realize the test cases of this test script.                          \n"+
               "***********************************************************************\n"+
               "**     Criteria for Evaluating Results:                                \n"+
               "**                                                                     \n"+
               "**     All data listed under Expected Outputs must exactly match       \n"+
               "**     the listed result or range expressed.                           \n"+
               "**                                                                     \n"+
               "***********************************************************************");
    }

    static IO_Unit_Test Unit_Test = null;
    String ClassName              = "L_BPCU_APP_TTP_Software_Synchronization";
    String Cov_File_Name          = "L_BPCU_APP_TTP_Software_Synchronization";
    String ClassName1             = "TTP_Software_Synchronization";

    /*Getting the Current working directory */
    String curDir       = System.getProperty("user.dir");
    String Cov_FilePath =  curDir + "\\SITE_Test_Results\\" + ClassName1 + ".tio";


    /**
     * Constructor for t_Unit_Test_PDRC_Exec.
     * @param name
     */
    public L_BPCU_APP_TTP_Software_Synchronization(String name) {
        super(name);
    }

    /**
     * Returns the JUnit test suite that implements the <b>t_Unit_Test_PDRC_Exec</b> definition.
     */
    public static Test suite() {
        HyadesTestSuite L_BPCU_APP_TTP_Software_Synchronization = new HyadesTestSuite(
                "L_BPCU_APP_TTP_Software_Synchronization");
        L_BPCU_APP_TTP_Software_Synchronization.setArbiter(DefaultTestArbiter.INSTANCE).setId(
                "A1DF2AD46991A430F943E66432376636");
        L_BPCU_APP_TTP_Software_Synchronization.addTest(new L_BPCU_APP_TTP_Software_Synchronization("tHeader")
                .setId("A1DF2AD46D248EF0F943E66432376636").setTestInvocationId(
                        "A1DF2AD478B86CF0F943E66432376636"));
        L_BPCU_APP_TTP_Software_Synchronization.addTest(new L_BPCU_APP_TTP_Software_Synchronization(
                "testScriptheader").setId("A1DF474228C75563F49FE66135323662")
                .setTestInvocationId("A1DF4742FFBCC860F49FE66135323662"));
        L_BPCU_APP_TTP_Software_Synchronization.addTest(new L_BPCU_APP_TTP_Software_Synchronization("tTC1").setId(
                "A1DF2AD470581BA0F943E66432376636").setTestInvocationId(
                "A1DF2AD478BD27E0F943E66432376636"));
        L_BPCU_APP_TTP_Software_Synchronization.addTest(new L_BPCU_APP_TTP_Software_Synchronization("tFooter")
                .setId("A1DF2AD472E75200F943E66432376636").setTestInvocationId(
                        "A1DF2AD478BD27E1F943E66432376636"));
        return L_BPCU_APP_TTP_Software_Synchronization;
    }

    /**
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
    }

    /**
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
    }

    /**
     * tHeader
     * @throws Exception
     */
    public void tHeader() throws Exception {

            /*Print the header information in the Result file */
            ResultFormatter.Header(curDir + "\\SITE_Test_Results\\" + ClassName + ".res");

            comms = new CommsPortTLP();

            /*Open the port and the Result file */

            unit = new PRODUCT_787_EPGS_MT(comms, curDir + "\\SITE_Test_Results\\" + ClassName + ".res",Cov_FilePath,"L_BPCU_APP_TTP_Software_Synchronization");

    }

    /**
     * tTC1
     * @throws Exception
     */
    public void tTC1() throws Exception {



        /*Set the Debug ON */
        comms.SetDebug();

        /*Call the test files */
        unit.Execute_TestGroups((byte)GlobalDataUT.TEST_NAME.L_BPCU_APP_TTP_Software_Synchronization_Per_Func.ordinal());

        unit.CSCI_Close();
    }

    /**
     * tFooter
     * @throws Exception
     */
    public void tFooter() throws Exception
    {


    }

}
