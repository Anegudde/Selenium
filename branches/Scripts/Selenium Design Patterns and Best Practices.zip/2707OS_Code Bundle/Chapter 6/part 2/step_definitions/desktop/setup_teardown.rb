Before do
   @selenium = SeleniumWrapper.new
end
