After do
  @selenium.quit
end