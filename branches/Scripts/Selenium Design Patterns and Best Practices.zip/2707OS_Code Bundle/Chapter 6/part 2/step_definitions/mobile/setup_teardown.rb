Before do
   @selenium = SeleniumWrapper.new(:firefox, true)
end
