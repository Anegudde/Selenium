Given "I am on a product page" do
  @selenium.get(TestData.get_base_url + "/our-love-is-special")
end
