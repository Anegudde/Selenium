class ContactUsPage < Page  
  def page_path
    "/contact-us/"
  end
end           



