include Body

class ErrorPage < Page
  
end


